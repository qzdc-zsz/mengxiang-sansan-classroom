const { app, BrowserWindow, shell, session, desktopCapturer, ipcMain, globalShortcut } = require('electron');
const { spawn } = require('node:child_process');
const { cp, mkdir, readFile, writeFile } = require('node:fs/promises');
const { createServer } = require('node:net');
const path = require('node:path');

let mainWindow;
let overlayWindow;
let serverProcess;
let appUrl;
let selectedCaptureSourceId = '';

function preloadPath() { return path.join(__dirname, 'preload.cjs'); }

async function openOverlayWindow(data) {
  if (overlayWindow && !overlayWindow.isDestroyed()) {
    overlayWindow.show(); overlayWindow.focus(); overlayWindow.webContents.send('overlay:data', data); return true;
  }
  overlayWindow = new BrowserWindow({
    width: 390, height: 230, minWidth: 320, minHeight: 190,
    frame: false, transparent: true, alwaysOnTop: true, skipTaskbar: true,
    resizable: true, movable: true, hasShadow: false,
    webPreferences: { preload: preloadPath(), contextIsolation: true, sandbox: true }
  });
  overlayWindow.setAlwaysOnTop(true, 'screen-saver');
  overlayWindow.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  overlayWindow.on('closed', () => { overlayWindow = null; });
  await overlayWindow.loadURL(`${appUrl}overlay-window.html`);
  overlayWindow.webContents.send('overlay:data', data);
  return true;
}

async function captureSources() {
  const sources = await desktopCapturer.getSources({ types: ['window', 'screen'], thumbnailSize: { width: 320, height: 180 }, fetchWindowIcons: true });
  return sources.filter(source => !/梦想三三小课堂|实战伤害悬浮窗/.test(source.name)).map(source => ({
    id: source.id, name: source.name, kind: source.id.startsWith('screen:') ? 'screen' : 'window',
    thumbnail: source.thumbnail?.isEmpty() ? '' : source.thumbnail.toDataURL()
  }));
}

function freePort() {
  return new Promise((resolve, reject) => {
    const probe = createServer();
    probe.once('error', reject);
    probe.listen(0, '127.0.0.1', () => {
      const port = probe.address().port;
      probe.close(() => resolve(port));
    });
  });
}

async function prepareRuntime() {
  if (!app.isPackaged) return __dirname;
  const source = path.join(process.resourcesPath, 'runtime');
  const target = path.join(app.getPath('userData'), 'runtime');
  const marker = path.join(target, '.app-version');
  let installedVersion = '';
  try { installedVersion = await readFile(marker, 'utf8'); } catch {}
  if (installedVersion !== app.getVersion()) {
    await mkdir(target, { recursive: true });
    await cp(source, target, { recursive: true, force: true });
    await writeFile(marker, app.getVersion(), 'utf8');
  }
  return target;
}

async function startLocalServer(runtime) {
  const port = await freePort();
  serverProcess = spawn(process.execPath, [path.join(runtime, 'server.js')], {
    cwd: runtime,
    windowsHide: true,
    stdio: 'ignore',
    env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', ROCO_PORT: String(port) }
  });
  await new Promise(resolve => setTimeout(resolve, 700));
  return `http://127.0.0.1:${port}/`;
}

async function createWindow() {
  const runtime = await prepareRuntime();
  const url = await startLocalServer(runtime); appUrl = url;
  session.defaultSession.setDisplayMediaRequestHandler(async (_request, callback) => {
    const sources = await desktopCapturer.getSources({ types: ['window', 'screen'], thumbnailSize: { width: 0, height: 0 } });
    const selected = sources.find(source => source.id === selectedCaptureSourceId);
    const game = sources.find(source => /洛克王国|roco\s*kingdom/i.test(source.name));
    callback({ video: selected || game || sources.find(source => source.id.startsWith('screen:')) || sources[0] });
  });
  mainWindow = new BrowserWindow({
    width: 1380,
    height: 900,
    minWidth: 900,
    minHeight: 650,
    backgroundColor: '#f4f7f5',
    icon: app.isPackaged ? path.join(process.resourcesPath, 'icon.png') : path.join(__dirname, 'build', 'icon.png'),
    title: '梦想三三小课堂',
    autoHideMenuBar: true,
    webPreferences: { preload: preloadPath(), contextIsolation: true, sandbox: true }
  });
  mainWindow.webContents.setWindowOpenHandler(({ url: target }) => {
    shell.openExternal(target);
    return { action: 'deny' };
  });
  await mainWindow.loadURL(url);
}

app.requestSingleInstanceLock() || app.quit();
ipcMain.handle('overlay:open', (_event, data) => openOverlayWindow(data));
ipcMain.on('overlay:update', (_event, data) => { if (overlayWindow && !overlayWindow.isDestroyed()) overlayWindow.webContents.send('overlay:data', data); });
ipcMain.on('overlay:close', () => overlayWindow?.close());
ipcMain.on('overlay:click-through', (_event, enabled) => overlayWindow?.setIgnoreMouseEvents(enabled, { forward: true }));
ipcMain.handle('capture:list-sources', () => captureSources());
ipcMain.handle('capture:select-source', (_event, id) => { selectedCaptureSourceId = String(id || ''); return true; });
app.on('second-instance', () => {
  if (mainWindow) { if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.focus(); }
});
app.whenReady().then(() => { globalShortcut.register('CommandOrControl+Shift+P', () => overlayWindow?.setIgnoreMouseEvents(false)); return createWindow(); }).catch(error => {
  const { dialog } = require('electron');
  dialog.showErrorBox('启动失败', error.stack || error.message);
  app.quit();
});
app.on('window-all-closed', () => app.quit());
app.on('before-quit', () => { globalShortcut.unregisterAll(); if (serverProcess && !serverProcess.killed) serverProcess.kill(); });
