const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('rocoDesktop', {
  openOverlay: data => ipcRenderer.invoke('overlay:open', data),
  updateOverlay: data => ipcRenderer.send('overlay:update', data),
  closeOverlay: () => ipcRenderer.send('overlay:close'),
  setOverlayClickThrough: enabled => ipcRenderer.send('overlay:click-through', Boolean(enabled)),
  onOverlayData: callback => ipcRenderer.on('overlay:data', (_event, data) => callback(data))
  ,listCaptureSources: () => ipcRenderer.invoke('capture:list-sources')
  ,selectCaptureSource: id => ipcRenderer.invoke('capture:select-source', id)
});
