@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo 未找到 Node.js。请先安装 Node.js 20 或更高版本。
  pause
  exit /b 1
)

echo 正在从公开数据源更新数据，请稍候……
call npm run sync-data
if errorlevel 1 (
  echo.
  echo 更新失败，原有数据仍可继续使用。请检查上方错误信息和网络连接。
  pause
  exit /b 1
)

echo.
echo 更新完成。重新打开或刷新助手页面即可使用新数据。
pause
