# 开源组件与参考项目

本项目使用或参考以下开源组件。发布安装包时应保留相应许可证文本。

- Electron：MIT License，用于 Windows 桌面应用封装。
- electron-builder：MIT License，用于生成 NSIS 安装包。
- Tesseract.js：Apache License 2.0，用于浏览器端本地文字识别。
- 《洛克王国：世界》Wiki 数据镜像：CC BY-NC-SA 4.0，精灵、技能、蛋组和图片资料来源之一。
- roco-claude：MIT License，图鉴与技能数据来源之一。

调研过但未直接复制代码的项目：

- YUZE04/Roco-pollution-counter：AGPL-3.0。参考了“识别冷却、OCR 别名、按对象记录”的产品思路，未复制源代码。
- HZ-KMNO/roco-sandbox：仅限教育与个人使用。参考了“按对局维护状态”的产品思路，未复制源代码。
- Makapic/RocoPilot：涉及驱动级输入和自动化操作，未集成。
- AofeiLi-code/rocom-data：参考了队伍名册、持久化、截图导入和对战分析的产品思路，未复制源代码。
- kikozz/Roco-Kingdom-World-Dex：参考了面向玩家的属性覆盖与图鉴展示思路，未复制源代码。

本项目的队伍规划与覆盖分析基于既有本地数据和属性表独立实现。

原生悬浮窗采用 Electron 官方 `BrowserWindow`、`setAlwaysOnTop`、`setIgnoreMouseEvents`、`globalShortcut` 与安全 preload/IPC 接口实现。

本助手只读取用户主动选择的游戏画面，不注入、读取或修改游戏进程。
