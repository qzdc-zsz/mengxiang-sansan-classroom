import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, resolve } from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const root = resolve('public');
const projectRoot = resolve('.');
const execFileAsync = promisify(execFile);
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json' };
let syncing = false;
createServer(async (req, res) => {
  if (req.method === 'POST' && new URL(req.url, 'http://localhost').pathname === '/api/sync') {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    if (syncing) { res.writeHead(409).end(JSON.stringify({ ok:false, message:'数据正在更新，请稍候。' })); return; }
    syncing = true;
    try {
      const { stdout, stderr } = await execFileAsync(process.execPath, ['scripts/sync-data.mjs'], { cwd:projectRoot, timeout:120000, maxBuffer:1024*1024*5 });
      res.writeHead(200).end(JSON.stringify({ ok:true, message:'数据更新完成', output:`${stdout}${stderr}`.trim() }));
    } catch (error) {
      res.writeHead(500).end(JSON.stringify({ ok:false, message:'更新失败，请检查网络连接后重试。', detail:`${error.stdout||''}${error.stderr||''}`.trim() }));
    } finally { syncing = false; }
    return;
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405).end(); return; }
  const path = resolve(join(root, decodeURIComponent(new URL(req.url, 'http://localhost').pathname === '/' ? 'index.html' : new URL(req.url, 'http://localhost').pathname.slice(1))));
  if (!path.startsWith(root + '\\') && path !== root) { res.writeHead(403).end(); return; }
  try { const body = await readFile(path); res.writeHead(200, { 'Content-Type': `${types[extname(path)] || 'application/octet-stream'}; charset=utf-8` }).end(body); }
  catch { res.writeHead(404).end('Not found'); }
}).listen(Number(process.env.ROCO_PORT)||5173, '127.0.0.1', () => console.log(`http://127.0.0.1:${Number(process.env.ROCO_PORT)||5173}`));
