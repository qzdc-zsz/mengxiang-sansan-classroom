import { TYPES, STATS, STAT_NAMES, calculateStats, calculateDamage, effectiveness, defensiveProfile } from './rules.js';
import { defaultChart, emptyBuild } from './data.js';
import { normalizeCreature, normalizeMove, buildFromCreature, isDamageMove, skillPool } from './catalog.js';
import { matchEggs } from './eggs.js';
import { analyzeTeam, sanitizeTeam, recommendTeammates } from './team.js';

const $ = id => document.getElementById(id);
const clone = x => structuredClone(x);
const saved = (() => { try { return JSON.parse(localStorage.getItem('roco-world-state')); } catch { return null; } })();
let state = saved || { attacker:emptyBuild('攻击方精灵'), defender:emptyBuild('防御方精灵'), chart:clone(defaultChart), creatures:[], moves:[] };
state.chart ||= clone(defaultChart); state.creatures ||= []; state.moves ||= [];
let imageMaps={pets:{},skills:{}};
let portraitIndex=[],portraitIndexLoading=false;
let eggData=[];
let eggGroups={};
const pages={creature:1,skill:1},pageSize=24;
let selectedCreature='',selectedSkill='';
let recentCreatureKeys=(()=>{try{return JSON.parse(localStorage.getItem('roco-recent-creatures'))||[]}catch{return[]}})();
let battlePresets=(()=>{try{return JSON.parse(localStorage.getItem('roco-battle-presets'))||[]}catch{return[]}})();
let plannedTeam=(()=>{try{return JSON.parse(localStorage.getItem('roco-planned-team'))||[]}catch{return[]}})();
const typeHue={普通:180,草:135,火:18,水:204,光:46,地:34,冰:188,龙:270,电:52,毒:300,虫:96,武:8,翼:192,萌:330,幽:265,恶:252,机械:204,幻:288};
const typeIcons={光:'https://patchwiki.biligame.com/images/nrc/thumb/e/eb/5d81xmmo6mwavqvbdhp1xevcp5e2rrq.png/23px-Type_6.png',冰:'https://patchwiki.biligame.com/images/nrc/thumb/5/54/tw7z68vd0r2fivv5i72y80wicgfifxk.png/24px-Type_9.png',地:'https://patchwiki.biligame.com/images/nrc/thumb/c/cf/sydcj72coawh39cyebnb8wiadq4d7a1.png/24px-Type_8.png',幻:'https://patchwiki.biligame.com/images/nrc/thumb/a/a7/1regqkg6b5skl52c69w2rz48biu158j.png/24px-Type_20.png',幽:'https://patchwiki.biligame.com/images/nrc/thumb/7/7f/hws03uwn2esdbipchpb495tolpedud9.png/24px-Type_17.png',恶:'https://patchwiki.biligame.com/images/nrc/thumb/4/47/sqaucq4ijmrt8zb5wpl5btbqzvg9rkb.png/24px-Type_18.png',普通:'https://patchwiki.biligame.com/images/nrc/thumb/3/35/b0gigz0reegycqg40ik3jayo5vhi4m1.png/24px-Type_2.png',机械:'https://patchwiki.biligame.com/images/nrc/thumb/b/b0/ectmfcsmc17y6gc9f9jpjrusme2zzo4.png/24px-Type_19.png',武:'https://patchwiki.biligame.com/images/nrc/thumb/a/a7/pr4f0yt60heec1o0ghwex1ov91obz9s.png/24px-Type_14.png',毒:'https://patchwiki.biligame.com/images/nrc/thumb/a/a5/nsgv1ypvaylyeg7pj3b4zsht16j5i0l.png/24px-Type_12.png',水:'https://patchwiki.biligame.com/images/nrc/thumb/7/73/43q0k2tn3u1qow3unucnvwx4p3ruycu.png/24px-Type_5.png',火:'https://patchwiki.biligame.com/images/nrc/thumb/5/56/0nfa46urnn7qjjhanyjvj1hq3n6ady6.png/24px-Type_4.png',电:'https://patchwiki.biligame.com/images/nrc/thumb/0/05/74v3mn737sst6nyhu1qx0f9nx9z7cnf.png/24px-Type_11.png',翼:'https://patchwiki.biligame.com/images/nrc/thumb/8/82/3izgedbios6n3xaui4whtwp5oytikf2.png/24px-Type_15.png',草:'https://patchwiki.biligame.com/images/nrc/thumb/b/b8/8fh2oym6ldwadc3qr2ynh2d8ramdqwp.png/24px-Type_3.png',萌:'https://patchwiki.biligame.com/images/nrc/thumb/6/6a/mj0letus7ogg5un813ogfg8egg7lmt5.png/24px-Type_16.png',虫:'https://patchwiki.biligame.com/images/nrc/thumb/8/8b/1f6jbb1cq4gkas862yg5xzoupu21vgh.png/24px-Type_13.png',龙:'https://patchwiki.biligame.com/images/nrc/thumb/c/c9/07lk3hkjg5585rpbxjev3864e7zz4vj.png/23px-Type_10.png'};
const typeOptions = (selected, blank=false) => `${blank?'<option value="">无</option>':''}${TYPES.map(t=>`<option value="${t}" ${t===selected?'selected':''}>${t}</option>`).join('')}`;
const skillTagWords={异常:['中毒','灼烧','冻结','异常'],回血:['回复生命','吸血'],回能:['回复能量'],应对:['应对'],印记:['印记'],驱散:['驱散'],先手:['先手'],离场:['离场','脱离'],天气:['天气','雨天','晴天','霜天','雷鸣'],选择:['选择：'],巧变:['巧变'],强化:['获得物攻','获得魔攻','获得双攻','获得双防','获得速度','威力永久'],连击:['连击'],萌化:['萌化'],引电:['引电'],迅捷:['迅捷'],传动:['传动'],迸发:['迸发'],奉献:['奉献'],打断:['打断']};
const skillTags = move => Object.entries(skillTagWords).filter(([,words])=>words.some(word=>(move.description||'').includes(word))).map(([tag])=>tag);
const statOptions = selected => `<option value="">无修正</option>${STATS.map(k=>`<option value="${k}" ${k===selected?'selected':''}>${STAT_NAMES[k]}</option>`).join('')}`;
const num = (value,min,max) => Number.isFinite(Number(value)) ? Math.max(min,Math.min(max,Number(value))) : min;
const statTotal = creature => STATS.reduce((sum,key)=>sum+(Number(creature.base?.[key])||0),0);
const views=['home','catalog','eggs','calculator','team','overlay','types','data'];
function showView(id){
  const target=views.includes(id)?id:'home';
  for(const view of views)$(view).classList.toggle('active-view',view===target);
  const notice=document.querySelector('main .notice:not(#fileWarning)');if(notice)notice.hidden=target!=='catalog';
  document.querySelectorAll('nav a[href^="#"]').forEach(a=>{const active=a.hash===`#${target}`;a.classList.toggle('active',active);if(active)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current')});
  window.scrollTo({top:0,behavior:'instant'});
}
function navigateView(id){if(location.hash!==`#${id}`)location.hash=id;else showView(id)}
function creatureChoiceLabel(c){return `${c.name}${c.formName?` · ${c.formName}`:''}${c.key?` · ${c.key}`:''}`}
function rememberCreature(c){recentCreatureKeys=[c.key,...recentCreatureKeys.filter(key=>key!==c.key)].slice(0,8);localStorage.setItem('roco-recent-creatures',JSON.stringify(recentCreatureKeys))}
function useCreature(side,c){state[side]=buildFromCreature(c);rememberCreature(c);renderBuild(side);if(side==='attacker')renderMoveLibrary();update()}
function renderBattlePresets(){
  const select=$('battlePreset');if(!select)return;
  const selected=select.value;select.innerHTML='<option value="">已保存的对局</option>'+battlePresets.map(item=>`<option value="${item.id}">${escapeHtml(item.name)}</option>`).join('');
  if(battlePresets.some(item=>String(item.id)===selected))select.value=selected;
  $('loadBattle').disabled=!select.value;$('deleteBattle').disabled=!select.value;
}
function saveBattlePreset(){
  const now=new Date(),name=`${state.attacker.name} → ${state.defender.name} · ${now.toLocaleDateString('zh-CN')} ${now.toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'})}`;
  battlePresets=[{id:Date.now(),name,attacker:clone(state.attacker),defender:clone(state.defender),move:readMove(),options:{...damageOptions(),targetHp:Number($('calcTargetHp').value)}},...battlePresets].slice(0,10);
  localStorage.setItem('roco-battle-presets',JSON.stringify(battlePresets));renderBattlePresets();$('battlePreset').value=String(battlePresets[0].id);renderBattlePresets();
}
function loadBattlePreset(){
  const preset=battlePresets.find(item=>String(item.id)===$('battlePreset').value);if(!preset)return;
  state.attacker=clone(preset.attacker);state.defender=clone(preset.defender);renderBuild('attacker');renderBuild('defender');renderMoveLibrary();
  $('moveName').value=preset.move.name;$('moveType').value=preset.move.type;$('category').value=preset.move.category;$('power').value=preset.move.power;$('movePreset').value=state.moves.some(m=>m.name===preset.move.name)?preset.move.name:'';
  for(const [id,key] of [['hits','hits'],['attackStage','attackStage'],['defenseStage','defenseStage'],['extra','extraMultiplier'],['reduction','reduction']])$(id).value=preset.options[key]??$(id).value;
  for(const [prefix,key] of [['a','attackerModifiers'],['d','defenderModifiers']])for(const [stat,suffix] of Object.entries(modifierFields))$(`${prefix}${suffix}`).value=preset.options[key]?.[stat]??0;
  for(const [prefix,key] of [['a','attackerLayers'],['d','defenderLayers']])for(const [stat,label] of [['atk','Atk'],['matk','Matk'],['def','Def'],['mdef','Mdef'],['speed','Speed']]){$(`${prefix}${label}Layers`).value=preset.options[key]?.[stat]?.layers??0;$(`${prefix}${label}LayerPct`).value=preset.options[key]?.[stat]?.percent??10}
  for(const key of ['starLayers','freezeLayers','poisonLayers','cuteLayers','enemyBuffLayers','powerAdd','powerPercent','comboAdd'])$(key).value=preset.options[key]??0;
  $('counterStatus').checked=!!preset.options.counterStatus;$('selfDebuffed').checked=!!preset.options.selfDebuffed;
  $('rain').checked=!!preset.options.rain;$('calcTargetHp').value=preset.options.targetHp??100;$('calcTargetHpValue').textContent=`${$('calcTargetHp').value}%`;update();
}

function renderBuild(side) {
  const b=state[side], el=$(side),current=state.creatures.find(c=>c.key===b.key),recent=recentCreatureKeys.map(key=>state.creatures.find(c=>c.key===key)).filter(Boolean).slice(0,5);
  el.innerHTML=`${current?`<div class="build-summary">${iconMarkup(current.name,current.types[0],'pets',false,current.key)}<div><strong>${escapeHtml(current.name)}</strong><span>${current.types.map(t=>`${escapeHtml(t)}系`).join(' / ')} · 种族总值 ${statTotal(current)}</span></div></div>`:''}<div class="fields two"><label>搜索并选择精灵<input data-field="preset" list="${side}CreatureChoices" value="${current?escapeHtml(creatureChoiceLabel(current)):''}" placeholder="输入名称快速查找" autocomplete="off"><datalist id="${side}CreatureChoices">${state.creatures.map(c=>`<option value="${escapeHtml(creatureChoiceLabel(c))}"></option>`).join('')}</datalist></label><label>精灵名称<input data-field="name" value="${escapeHtml(b.name)}"></label><label>主属性<select data-field="type0">${typeOptions(b.types[0])}</select></label><label>副属性<select data-field="type1">${typeOptions(b.types[1],true)}</select></label><label>性格提升<select data-field="up">${statOptions(b.nature?.up)}</select></label><label>性格降低<select data-field="down">${statOptions(b.nature?.down)}</select></label></div>${recent.length?`<div class="recent-creatures"><small>最近使用</small>${recent.map(c=>`<button type="button" data-recent-key="${escapeHtml(c.key)}">${escapeHtml(c.name)}</button>`).join('')}</div>`:''}<p class="muted" id="${side}Stats"></p><details class="build-advanced"><summary>高级配置 · 种族值与个体值</summary><div class="iv-toolbar"><span id="${side}IvStatus">已分配 0 / 3 项</span><button type="button" data-clear-ivs>清空个体值</button></div><p class="subhead">个体值每项 0～10，最多分配 3 项</p><div class="fields two">${STATS.map(k=>`<label>${STAT_NAMES[k]}种族<input data-base="${k}" type="number" min="0" max="999" value="${b.base[k]}"></label><label>${STAT_NAMES[k]}个体<input data-iv="${k}" type="number" min="0" max="10" value="${b.iv[k]}"></label>`).join('')}</div></details>`;
  el.oninput=()=>readBuild(side);
  el.onchange=e=>{if(e.target.dataset.field==='preset' && e.target.value!==''){const c=state.creatures.find(item=>creatureChoiceLabel(item)===e.target.value)||state.creatures.find(item=>item.name===e.target.value);if(c)useCreature(side,c)}else readBuild(side)};
  el.querySelectorAll('[data-recent-key]').forEach(button=>button.onclick=()=>{const c=state.creatures.find(item=>item.key===button.dataset.recentKey);if(c)useCreature(side,c)});
  el.querySelector('[data-clear-ivs]').onclick=()=>{for(const key of STATS)b.iv[key]=0;renderBuild(side);update()};updateIvStatus(side);
}
function updateIvStatus(side){
  const el=$(side),status=$(`${side}IvStatus`);if(!el||!status)return;
  const inputs=[...el.querySelectorAll('[data-iv]')],count=inputs.filter(input=>Number(input.value)>0).length,invalid=count>3;
  status.textContent=invalid?`已分配 ${count} / 3 项，请减少 ${count-3} 项`:`已分配 ${count} / 3 项`;
  status.classList.toggle('invalid',invalid);el.querySelector('.build-advanced')?.classList.toggle('iv-invalid',invalid);
}
function readBuild(side){
  const el=$(side), b=state[side], get=s=>el.querySelector(s);
  b.name=get('[data-field=name]').value;
  b.types=[get('[data-field=type0]').value,get('[data-field=type1]').value].filter(Boolean);
  b.nature={up:get('[data-field=up]').value,down:get('[data-field=down]').value};
  for(const k of STATS){b.base[k]=num(get(`[data-base=${k}]`).value,0,999);b.iv[k]=num(get(`[data-iv=${k}]`).value,0,10)}
  updateIvStatus(side);update();
}
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function readMove(){return {name:$('moveName').value,type:$('moveType').value,category:$('category').value,power:Number($('power').value)}}
const modifierFields={hp:'HpMod',atk:'AtkMod',def:'DefMod',matk:'MatkMod',mdef:'MdefMod',speed:'SpeedMod'};
function sideModifiers(prefix){return Object.fromEntries(Object.entries(modifierFields).map(([key,suffix])=>[key,Number($(`${prefix}${suffix}`).value)]))}
function sideLayers(prefix){return Object.fromEntries([['atk','Atk'],['matk','Matk'],['def','Def'],['mdef','Mdef'],['speed','Speed']].map(([key,label])=>[key,{layers:Number($(`${prefix}${label}Layers`).value),percent:Number($(`${prefix}${label}LayerPct`).value)}]))}
function damageOptions(){return {hits:Number($('hits').value),energy:Number($('moveEnergy').value),attackStage:Number($('attackStage').value),defenseStage:Number($('defenseStage').value),extraMultiplier:Number($('extra').value),reduction:Number($('reduction').value),rain:$('rain').checked,attackerModifiers:sideModifiers('a'),defenderModifiers:sideModifiers('d'),attackerLayers:sideLayers('a'),defenderLayers:sideLayers('d'),starLayers:Number($('starLayers').value),freezeLayers:Number($('freezeLayers').value),poisonLayers:Number($('poisonLayers').value),cuteLayers:Number($('cuteLayers').value),enemyBuffLayers:Number($('enemyBuffLayers').value),powerAdd:Number($('powerAdd').value),powerPercent:Number($('powerPercent').value),comboAdd:Number($('comboAdd').value),counterStatus:$('counterStatus').checked,selfDebuffed:$('selfDebuffed').checked}}
function powerRuleLabel(rule){return rule?(rule.energy!=null?`${rule.rule} ${rule.energy}`:`${rule.rule} ${rule.difference>=0?'+':''}${rule.difference}`):''}
function renderCalcRecommendations(){
  const creature=attackerCreature(),defender=defenderCreature(),container=$('calcRecommendations'),counter=$('counterRecommendations');if(!container||!counter)return;
  if(creature){
    const currentHp=calculateStats(state.defender).hp*Number($('calcTargetHp').value)/100;
    const ranked=skillPool(creature,state.moves).map(x=>x.move).filter(Boolean).filter(isDamageMove).map(move=>({move,result:calculateDamage(state.attacker,state.defender,move,state.chart,damageOptions())})).sort((a,b)=>b.result.damage-a.result.damage);
    container.innerHTML=ranked.slice(0,8).map((item,index)=>{const lethal=item.result.damage>=currentHp,turns=Math.max(1,Math.ceil(currentHp/item.result.damage));return `<button data-calc-move="${state.moves.indexOf(item.move)}" class="recommend-row ${readMove().name===item.move.name?'active':''}"><b>${index+1}</b><span><strong>${escapeHtml(item.move.name)}</strong><small>${escapeHtml(item.move.type)}系 · ${escapeHtml(item.move.categoryLabel)} · 威力 ${item.move.power}</small></span><em>${item.result.damage}</em><i class="${lethal?'lethal':''}">${lethal?'可击败':`${turns} 次`}</i></button>`}).join('')||'<p class="muted">当前精灵技能池中没有可直接计算的伤害技能。</p>';
    container.querySelectorAll('[data-calc-move]').forEach(button=>button.onclick=()=>setMove(state.moves[Number(button.dataset.calcMove)]));
  }else container.innerHTML='<p class="muted">从图鉴选择攻击方后生成技能排行。</p>';
  if(defender){
    const targetHp=calculateStats(state.attacker).hp,neutral={rain:$('rain').checked};
    const threats=skillPool(defender,state.moves).map(x=>x.move).filter(Boolean).filter(isDamageMove).map(move=>({move,result:calculateDamage(state.defender,state.attacker,move,state.chart,neutral)})).sort((a,b)=>b.result.damage-a.result.damage);
    counter.innerHTML=threats.slice(0,8).map((item,index)=>{const lethal=item.result.damage>=targetHp,turns=Math.max(1,Math.ceil(targetHp/item.result.damage));return `<button data-counter-move="${state.moves.indexOf(item.move)}" class="recommend-row threat"><b>${index+1}</b><span><strong>${escapeHtml(item.move.name)}</strong><small>${escapeHtml(item.move.type)}系 · 中性能力等级</small></span><em>${item.result.damage}</em><i class="${lethal?'lethal':''}">${lethal?'危险':`${turns} 次`}</i></button>`}).join('')||'<p class="muted">对方技能池中没有可直接计算的伤害技能。</p>';
    counter.querySelectorAll('[data-counter-move]').forEach(button=>button.onclick=()=>{const move=state.moves[Number(button.dataset.counterMove)];[state.attacker,state.defender]=[state.defender,state.attacker];renderBuild('attacker');renderBuild('defender');renderMoveLibrary();setMove(move)});
  }else counter.innerHTML='<p class="muted">从图鉴选择防御方后生成威胁排行。</p>';
}
function update(){
  try{
    const r=calculateDamage(state.attacker,state.defender,readMove(),state.chart,damageOptions());
    const a=r.attackerStats,d=r.defenderStats;
    $('attackerStats').textContent=STATS.map(k=>`${STAT_NAMES[k]} ${a[k]}`).join(' · ');
    $('defenderStats').textContent=STATS.map(k=>`${STAT_NAMES[k]} ${d[k]}`).join(' · ');
    $('result').classList.remove('error');
    const speedText=a.speed===d.speed?`速度相同（${a.speed}），可能同时判定`:a.speed>d.speed?`${escapeHtml(state.attacker.name)}先手 · ${a.speed} ＞ ${d.speed}`:`${escapeHtml(state.defender.name)}先手 · ${d.speed} ＞ ${a.speed}`;
    const targetHp=d.hp*Number($('calcTargetHp').value)/100,lethal=r.damage>=targetHp,turns=Math.max(1,Math.ceil(targetHp/r.damage));
    const powerRuleText=r.factors.powerRule?`（${powerRuleLabel(r.factors.powerRule)}）`:'';
    const split=r.starDamage?`技能 ${r.skillDamage} + 星陨 ${r.starDamage}`:`单段 ${r.perHit} × ${r.hits} 段`;
    $('result').innerHTML=`<small>预计总伤害 · ${escapeHtml(readMove().name)}</small><div class="big">${r.damage}</div><div>${split} · 约占目标生命 ${r.hpPercent.toFixed(1)}%</div><div class="battle-verdict ${lethal?'lethal':''}">${lethal?'✓ 可击败当前血量目标':`预计还需 ${turns} 次攻击`}</div><div class="speed-line">⚡ ${speedText}</div>${r.notes.length?`<div class="factor-list">${r.notes.map(note=>`<span>${escapeHtml(note)}</span>`).join('')}</div>`:''}<div class="factor-list"><span>攻 / 防 ${r.factors.attack} / ${r.factors.defense}</span><span>实际威力 ${r.factors.power}${powerRuleText}</span><span>本系 ×${r.factors.stab}</span><span>克制 ×${r.factors.type}</span><span>能力 ×${r.factors.stage.toFixed(2)}</span><span>天气 ×${r.factors.weather}</span><span>额外 ×${r.factors.extra}</span><span>减伤 ${Math.round(r.factors.reduction*100)}%</span></div>`;
    renderCalcRecommendations();localStorage.setItem('roco-world-state',JSON.stringify({attacker:state.attacker,defender:state.defender,chart:state.chart}));
  }catch(e){$('result').classList.add('error');$('result').textContent=e.message}
  try{$('typeSummary').textContent=`当前技能 ${$('moveType').value} → 防御方 ${state.defender.types.join('/')}：×${effectiveness($('moveType').value,state.defender.types,state.chart)}`}catch{}
}
function renderChart(){
  $('typeTable').innerHTML=`<thead><tr><th>攻 ↓ / 防 →</th>${TYPES.map(t=>`<th>${t}</th>`).join('')}</tr></thead><tbody>${TYPES.map(at=>`<tr><th>${at}</th>${TYPES.map(dt=>{const n=state.chart[at]?.[dt]??1;return `<td data-at="${at}" data-dt="${dt}" class="${n>1?'strong':n===0?'zero':n<1?'weak':''}">${n}</td>`}).join('')}</tr>`).join('')}</tbody>`;
}
function renderDefensiveProfile(){
  const types=[$('profileType0').value,$('profileType1').value].filter(Boolean);
  try{
    const grouped=new Map();
    for(const [type,key] of Object.entries(defensiveProfile(types,state.chart))){if(!grouped.has(key))grouped.set(key,[]);grouped.get(key).push(type)}
    $('defensiveProfile').innerHTML=[...grouped].sort((a,b)=>b[0]-a[0]).map(([factor,names])=>`<div class="profile-card factor-${String(factor).replace('.','-')}"><header><strong>×${factor}</strong><span>${factor>=3?'三倍克制':factor>1?'克制':factor===1?'正常伤害':factor===0?'免疫':factor<=.25?'四倍抵抗':'抵抗'}</span></header><div class="type-token-list">${names.map(name=>`<span><img src="${typeIcons[name]}" alt="">${escapeHtml(name)}</span>`).join('')}</div></div>`).join('');
  }catch(e){$('defensiveProfile').textContent=e.message}
}
function renderTypePickers(){
  for(const [selectId,pickerId,allowBlank] of [['profileType0','profileTypePicker0',false],['profileType1','profileTypePicker1',true]]){
    const select=$(selectId),picker=$(pickerId);if(!picker)return;
    const choices=allowBlank?['',...TYPES]:TYPES;
    picker.innerHTML=choices.map(type=>`<button type="button" class="type-choice ${select.value===type?'selected':''}" data-type="${type}" aria-pressed="${select.value===type}">${type?`<img src="${typeIcons[type]}" alt=""><span>${type}</span>`:'<span class="none-icon">—</span><span>无</span>'}</button>`).join('');
    picker.onclick=e=>{const button=e.target.closest('[data-type]');if(!button)return;select.value=button.dataset.type;renderTypePickers();renderDefensiveProfile()};
  }
}
function validCreature(c){return c && typeof c.name==='string' && Array.isArray(c.types) && c.types.length>=1 && c.types.length<=2 && c.types.every(t=>TYPES.includes(t)) && STATS.every(k=>Number.isInteger(c.base?.[k])&&c.base[k]>=0&&c.base[k]<=999)}
function validMove(m){return m && typeof m.name==='string' && TYPES.includes(m.type) && ['physical','magic'].includes(m.category) && Number.isFinite(m.power) && m.power>=0}
function validChart(chart){if(!chart||typeof chart!=='object')return false;return Object.entries(chart).every(([a,row])=>TYPES.includes(a)&&row&&typeof row==='object'&&Object.entries(row).every(([d,n])=>TYPES.includes(d)&&[0,.25,.5,1,2,3].includes(n)))}
function attackerCreature(){return state.creatures.find(c=>c.key===state.attacker.key)}
function defenderCreature(){return state.creatures.find(c=>c.key===state.defender.key)}
function imageFor(name,kind,key){
  const petKey=key||state.creatures.find(c=>c.name===name)?.key;
  const filename=kind==='pets'?imageMaps.pets[petKey]:imageMaps.skills[name];
  if(filename)return /^https?:\/\//.test(filename)?filename:`https://wiki.biligame.com/nrc/Special:Redirect/file/${encodeURIComponent(filename)}`;
  return '';
}
function imageSignature(source,sx=0,sy=0,sw=source.width,sh=source.height){
  const canvas=document.createElement('canvas');canvas.width=12;canvas.height=12;
  const context=canvas.getContext('2d',{willReadFrequently:true});context.drawImage(source,sx,sy,sw,sh,0,0,12,12);
  const pixels=context.getImageData(0,0,12,12).data,values=[];
  for(let channel=0;channel<3;channel++){let mean=0;for(let i=0;i<144;i++)mean+=pixels[i*4+channel];mean/=144;for(let i=0;i<144;i++)values.push((pixels[i*4+channel]-mean)/255)}
  const norm=Math.hypot(...values)||1;return values.map(value=>value/norm);
}
function signatureSimilarity(a,b){let sum=0;for(let i=0;i<a.length;i++)sum+=a[i]*b[i];return sum}
async function buildPortraitIndex(){
  if(portraitIndexLoading||portraitIndex.length)return;portraitIndexLoading=true;
  const queue=state.creatures.map(creature=>({creature,url:imageFor(creature.name,'pets',creature.key)})).filter(item=>item.url);
  let cursor=0;const worker=async()=>{while(cursor<queue.length){const item=queue[cursor++];try{const image=new Image();image.crossOrigin='anonymous';await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=reject;image.src=item.url});portraitIndex.push({creature:item.creature,signature:imageSignature(image)})}catch{}}};
  await Promise.all(Array.from({length:8},worker));portraitIndexLoading=false;
}
function matchPortrait(video,left,top,right,bottom){
  if(!portraitIndex.length)return null;
  const signature=imageSignature(video,Math.round(video.videoWidth*left),Math.round(video.videoHeight*top),Math.round(video.videoWidth*(right-left)),Math.round(video.videoHeight*(bottom-top)));
  const ranked=portraitIndex.map(item=>({...item,score:signatureSimilarity(signature,item.signature)})).sort((a,b)=>b.score-a.score);
  return ranked[0]?.score>.62&&ranked[0].score-ranked[1].score>.015?ranked[0]:null;
}
function recognizeBattlePortraits(video){
  const own=matchPortrait(video,.175,.045,.225,.145),enemy=matchPortrait(video,.835,.045,.89,.145);
  if(own){const index=state.creatures.indexOf(own.creature);$('overlayAttacker').value=String(index);fillOverlaySelectors();$('overlayAttacker').value=String(index)}
  if(enemy)$('overlayDefender').value=String(state.creatures.indexOf(enemy.creature));
  return {own,enemy};
}
function iconMarkup(name,type,kind,large=false,key){
  const url=imageFor(name,kind,key),hue=typeHue[type]??180;
  return `<span class="icon-frame ${large?'large':''}" style="--type-hue:${hue}" aria-hidden="true"><span class="icon-fallback">${escapeHtml(type.slice(0,1))}</span>${url?`<img src="${escapeHtml(url)}" alt="" loading="lazy" onerror="this.remove()">`:''}</span>`;
}
function renderEggs(){
  const h=$('eggHeight').value,w=$('eggWeight').value,out=$('eggResults');
  if(!h&&!w){out.textContent='输入蛋径或蛋重查看可能的精灵。';return}
  if((h&&Number(h)<=0)||(w&&Number(w)<=0)){out.textContent='请输入大于零的数值。';return}
  const matches=matchEggs(eggData,h,w);
  out.innerHTML=matches.length?`<p class="muted">找到 ${matches.length} 种可能的精灵${h&&!w?'；仅有蛋重资料的精灵不会出现在按蛋径查询的结果中。':''}</p><div class="egg-list">${matches.map(e=>`<article class="egg-card">${iconMarkup(e.name,'普通','pets')}<div><strong>${escapeHtml(e.name)}</strong><small>蛋径 ${e.heightMin!=null?`${e.heightMin}–${e.heightMax} m`:'暂无'} · 蛋重 ${e.weightMin}–${e.weightMax} kg</small><small>${e.groups?.length?escapeHtml(e.groups.join(' / '))+' · ':''}${escapeHtml(e.sizeVerdict||'输入蛋重可估算体型')}</small></div></article>`).join('')}</div>`:'<p class="muted">未找到匹配记录。可核对单位（米、千克）或只用一项查询。</p>';
}
function renderMoveLibrary(){
  const creature=attackerCreature(),pool=skillPool(creature,state.moves),select=$('movePreset');
  $('movePresetChoices').innerHTML=pool.filter(item=>item.move&&isDamageMove(item.move)).map(item=>`<option value="${escapeHtml(item.move.name)}">${escapeHtml(item.pool)} · ${escapeHtml(item.move.type)}系 · 威力 ${item.move.power}</option>`).join('');
  if(!state.moves.some(move=>move.name===select.value))select.value='';
  let hint=$('skillPoolHint');if(!hint){hint=document.createElement('p');hint.id='skillPoolHint';hint.className='muted pool-hint';select.parentElement.after(hint)}
  hint.textContent=creature?`${creature.name}的技能池：${pool.length} 项；状态、防御技能可在图鉴查看。`:'先选择攻击方精灵，技能列表将按其技能池筛选。';
}
function renderCatalog(){
  const creatureScroll=$('creatureList').scrollTop,skillScroll=$('skillList').scrollTop;
  const cq=$('creatureSearch').value.trim().toLowerCase(),ct=$('creatureType').value;
  const group=$('eggGroup').value,stage=$('creatureStage').value,sort=$('creatureSort').value;
  const creatures=state.creatures.filter(c=>(!ct||c.types.includes(ct))&&(!group||(eggGroups[c.name]||eggGroups[c.baseName]||[]).includes(group))&&(!cq||`${c.name} ${c.key||''}`.toLowerCase().includes(cq))&&(!stage||(stage==='final'&&c.evolution?.is_final_stage)||(stage==='base'&&Number(c.evolution?.evolution_stage||1)===1)||(stage==='boss'&&c.formName==='首领形态')));
  if(sort==='total-desc')creatures.sort((a,b)=>statTotal(b)-statTotal(a));else if(sort==='total-asc')creatures.sort((a,b)=>statTotal(a)-statTotal(b));else if(sort==='speed-desc')creatures.sort((a,b)=>b.base.speed-a.base.speed);
  pages.creature=Math.min(pages.creature,Math.max(1,Math.ceil(creatures.length/pageSize)));
  $('creatureList').innerHTML=creatures.slice((pages.creature-1)*pageSize,pages.creature*pageSize).map(c=>`<button class="entry-card ${c.key===selectedCreature?'active':''}" role="option" aria-selected="${c.key===selectedCreature}" data-key="${escapeHtml(c.key||c.name)}">${iconMarkup(c.name,c.types[0],'pets',false,c.key)}<span class="entry-copy"><strong>${escapeHtml(c.name)}</strong><small>${escapeHtml(c.types.join('/'))} · ${escapeHtml(c.key||'自定义')}</small><span class="mini-tags">总值 ${statTotal(c)} · 速度 ${c.base.speed}</span></span></button>`).join('')||'<p class="muted">没有匹配的精灵</p>';
  $('creaturePage').textContent=`第 ${pages.creature} / ${Math.max(1,Math.ceil(creatures.length/pageSize))} 页 · ${creatures.length} 项`;
  $('creaturePrev').disabled=pages.creature===1;$('creatureNext').disabled=pages.creature*pageSize>=creatures.length;
  const sq=$('skillSearch').value.trim().toLowerCase(),st=$('skillType').value,sc=$('skillCategory').value,stag=$('skillTag').value;
  const moves=state.moves.filter(m=>(!st||m.type===st)&&(!sc||m.categoryLabel===sc)&&(!stag||skillTags(m).includes(stag))&&(!sq||`${m.name} ${m.description||''}`.toLowerCase().includes(sq)));
  pages.skill=Math.min(pages.skill,Math.max(1,Math.ceil(moves.length/pageSize)));
  $('skillList').innerHTML=moves.slice((pages.skill-1)*pageSize,pages.skill*pageSize).map(m=>`<button class="entry-card ${m.name===selectedSkill?'active':''}" role="option" aria-selected="${m.name===selectedSkill}" data-name="${escapeHtml(m.name)}">${iconMarkup(m.name,m.type,'skills')}<span class="entry-copy"><strong>${escapeHtml(m.name)}</strong><small>${escapeHtml(m.type)} · ${escapeHtml(m.categoryLabel||m.category)} · 威力 ${m.power??'—'} · 耗能 ${escapeHtml(m.energy??'—')}</small>${skillTags(m).length?`<span class="mini-tags">${skillTags(m).slice(0,3).map(escapeHtml).join(' · ')}</span>`:''}</span></button>`).join('')||'<p class="muted">没有匹配的技能</p>';
  $('skillPage').textContent=`第 ${pages.skill} / ${Math.max(1,Math.ceil(moves.length/pageSize))} 页 · ${moves.length} 项`;
  $('skillPrev').disabled=pages.skill===1;$('skillNext').disabled=pages.skill*pageSize>=moves.length;
  $('catalogCount').textContent=`${state.creatures.length} 条精灵形态 · ${state.moves.length} 条技能`;
  if($('homeCatalogCount'))$('homeCatalogCount').textContent=`${state.creatures.length} 精灵 · ${state.moves.length} 技能`;
  $('creatureList').scrollTop=creatureScroll;$('skillList').scrollTop=skillScroll;
}
function showCreature(){
  const c=state.creatures.find(x=>(x.key||x.name)===selectedCreature);if(!c)return;
  const pools=[['普通技能',c.skillPools?.moves],['技能石',c.skillPools?.jinengshi],['血脉技能',c.skillPools?.xuemai]].map(([title,names])=>[title,Array.isArray(names)?names:names&&typeof names==='object'?Object.values(names):[]]);
  const evolution=state.creatures.filter(item=>item.evolution?.chain_group&&item.evolution.chain_group===c.evolution?.chain_group).sort((a,b)=>(a.evolution?.evolution_stage||0)-(b.evolution?.evolution_stage||0));
  $('creatureDetail').innerHTML=`<div class="record-banner"><span>精灵详情 · 种族总值 ${statTotal(c)}</span><b>${escapeHtml(c.key||'自定义')}</b></div><div class="detail-heading wiki-hero">${iconMarkup(c.name,c.types[0],'pets',true,c.key)}<div><h3>${escapeHtml(c.name)}</h3><p>${c.types.map(t=>`<span class="type-pill">${escapeHtml(t)}系</span>`).join('')}${c.formName?`<span class="soft-pill">${escapeHtml(c.formName)}</span>`:''}</p><small>特性 · ${escapeHtml(c.ability||'暂无资料')}</small></div></div><div class="metric-grid">${STATS.map(k=>`<div><span>${STAT_NAMES[k]}</span><strong>${c.base[k]}</strong></div>`).join('')}</div>${evolution.length>1?`<section class="info-section"><h4>进化链 <em>${evolution.length}</em></h4><div class="evolution-row">${evolution.map((item,index)=>`${index?'<i>›</i>':''}<button data-evolution="${escapeHtml(item.key)}">${iconMarkup(item.name,item.types[0],'pets',false,item.key)}<span>${escapeHtml(item.name)}</span></button>`).join('')}</div></section>`:''}${pools.map(([title,names])=>`<section class="info-section"><h4>${title}<em>${names?.length||0}</em></h4><div class="tag-cloud">${(names||[]).map(n=>`<button class="tag" data-skill-link="${escapeHtml(n)}">${escapeHtml(n)}</button>`).join('')||'<span class="muted">暂无资料</span>'}</div></section>`).join('')}<div class="detail-actions"><button data-use="attacker">设为攻击方</button><button data-use="defender" class="ghost">设为防御方</button></div>`;
  $('creatureDetail').querySelectorAll('[data-use]').forEach(button=>button.onclick=()=>{useCreature(button.dataset.use,c);navigateView('calculator')});
  $('creatureDetail').querySelectorAll('[data-evolution]').forEach(button=>button.onclick=()=>{selectedCreature=button.dataset.evolution;renderCatalog();showCreature()});
  $('creatureDetail').querySelectorAll('[data-skill-link]').forEach(button=>button.onclick=()=>{$('skillSearch').value=button.dataset.skillLink;$('skillCategory').value='';$('skillTag').value='';pages.skill=1;selectedSkill=button.dataset.skillLink;renderCatalog();showSkill()});
}
function showSkill(){
  const m=state.moves.find(x=>x.name===selectedSkill);if(!m)return;
  const pool=attackerCreature()?skillPool(attackerCreature(),state.moves):null;
  const allowed=!pool||pool.some(item=>item.name===m.name||item.move?.name===m.name);
  $('skillDetail').innerHTML=`<div class="record-banner"><span>技能详情</span><b>${escapeHtml(m.id)}</b></div><div class="detail-heading wiki-hero">${iconMarkup(m.name,m.type,'skills',true)}<div><h3>${escapeHtml(m.name)}</h3><p><span class="type-pill">${escapeHtml(m.type)}系</span><span class="soft-pill">${escapeHtml(m.categoryLabel||m.category)}</span></p><small>${escapeHtml(m.description||'暂无资料')}</small></div></div><div class="skill-metrics"><div><span>威力</span><strong>${m.power??'—'}</strong></div><div><span>耗能</span><strong>${escapeHtml(m.energy??'—')}</strong></div></div><section class="info-section"><h4>可学习精灵 <em>${m.learners?.length||0}</em></h4><div class="learner-grid">${(m.learners||[]).map(c=>`<span>${iconMarkup(c.name,'普通','pets',false,c.key)}<b>${escapeHtml(c.name)}</b></span>`).join('')||'<span class="muted">暂无学习关系资料</span>'}</div></section>${isDamageMove(m)&&allowed?'<div class="detail-actions"><button id="useSkill">用于伤害计算</button></div>':`<p class="muted">${allowed?'状态或防御技能没有直接伤害。':'当前攻击方的技能池不含此技能。'}</p>`}`;
  const button=$('useSkill');if(button)button.onclick=()=>{setMove(m);navigateView('calculator')};
}
function setMove(m){$('moveName').value=m.name;$('moveType').value=m.type;$('category').value=m.category;$('power').value=m.power;$('movePreset').value=m.name;update()}

function savePlannedTeam(){
  localStorage.setItem('roco-planned-team',JSON.stringify(plannedTeam));
}
function renderTeamPlanner(){
  if(!$('teamMembers'))return;
  plannedTeam=sanitizeTeam(plannedTeam,state.creatures,state.moves,skillPool);savePlannedTeam();
  $('teamCount').textContent=`${plannedTeam.length} / 6`;
  $('addTeamMember').disabled=plannedTeam.length>=6;
  $('teamCreatureChoices').innerHTML=state.creatures.map(c=>`<option value="${escapeHtml(creatureChoiceLabel(c))}"></option>`).join('');
  $('teamMembers').innerHTML=plannedTeam.length?plannedTeam.map((member,index)=>{
    const creature=state.creatures.find(c=>c.key===member.creatureKey);if(!creature)return'';
    const pool=skillPool(creature,state.moves).map(item=>item.move||state.moves.find(move=>move.name===item.name)).filter(Boolean);
    const choices='<option value="">未配置</option>'+pool.map(move=>`<option value="${escapeHtml(move.name)}">${escapeHtml(move.name)} · ${escapeHtml(move.type)}系 · ${escapeHtml(move.categoryLabel||move.category)}</option>`).join('');
    return `<article class="team-member" data-team-index="${index}"><div class="team-member-head">${iconMarkup(creature.name,creature.types[0],'pets',true,creature.key)}<div><span class="team-position">${String(index+1).padStart(2,'0')}</span><h3>${escapeHtml(creature.name)}</h3><p>${creature.types.map(type=>`<span class="type-pill">${escapeHtml(type)}系</span>`).join('')}</p><small>${escapeHtml(creature.ability||'暂无特性资料')} · 种族总值 ${statTotal(creature)}</small></div><button class="danger-ghost remove-team-member" data-index="${index}">移除</button></div><div class="team-skills">${[0,1,2,3].map(slot=>`<label>技能 ${slot+1}<select data-team-skill="${index}" data-slot="${slot}">${choices}</select></label>`).join('')}</div><div class="team-member-actions"><button class="ghost use-team-attacker" data-index="${index}">设为伤害计算攻击方</button></div></article>`;
  }).join(''):'<p class="muted team-empty">从上方选择精灵开始组队。</p>';
  plannedTeam.forEach((member,index)=>member.skills.forEach((name,slot)=>{const select=document.querySelector(`[data-team-skill="${index}"][data-slot="${slot}"]`);if(select)select.value=name}));
  const report=analyzeTeam(plannedTeam,state.creatures,state.moves,state.chart,effectiveness);
  $('teamCoverage').innerHTML=report.attackTypes.length?`<p class="muted">已配置攻击属性：${report.attackTypes.map(escapeHtml).join('、')}</p><div class="coverage-summary"><strong>${report.coveredTypes.length} / ${TYPES.length}</strong><span>种单属性可打出克制伤害</span></div><h4>已覆盖</h4><div class="analysis-tags">${report.coveredTypes.map(type=>`<span class="good">${escapeHtml(type)}</span>`).join('')||'<span>暂无</span>'}</div><h4>未覆盖</h4><div class="analysis-tags">${report.uncoveredTypes.map(type=>`<span class="warn">${escapeHtml(type)}</span>`).join('')}</div>`:'<p class="muted">为队员配置伤害技能后显示属性覆盖。</p>';
  $('teamRisks').innerHTML=plannedTeam.length?report.risks.map(item=>`<div class="risk-row ${item.weak>item.resist?'high':''}"><strong>${escapeHtml(item.type)}系</strong><span>${item.weak} 只弱点</span><span>${item.resist} 只抵抗</span><b>${item.weak>item.resist?'需补强':item.resist>item.weak?'有联防':'均衡'}</b></div>`).join(''):'<p class="muted">加入精灵后显示全队共同弱点与抵抗。</p>';
  const recommendations=recommendTeammates(plannedTeam,state.creatures,state.moves,state.chart,effectiveness,skillPool);
  $('teamRecommendations').innerHTML=!plannedTeam.length?'<p class="muted">先加入一只精灵，再根据弱点推荐补位。</p>':plannedTeam.length>=6?'<p class="muted">队伍已满。移除一名队员后可以继续查看补位推荐。</p>':recommendations.length?recommendations.map((item,index)=>{const creature=state.creatures.find(c=>c.key===item.creatureKey);return `<button class="team-recommendation" data-recommend-key="${escapeHtml(item.creatureKey)}"><b>${index+1}</b>${iconMarkup(creature.name,creature.types[0],'pets',false,creature.key)}<span><strong>${escapeHtml(creature.name)}</strong><small>${item.reasons.map(escapeHtml).join('；')}</small></span><em>适配 ${item.score.toFixed(1)}</em></button>`}).join(''):'<p class="muted">当前没有明显优于其他精灵的补位建议。</p>';
}
function addTeamMember(){
  const text=$('teamCreature').value.trim();
  const creature=state.creatures.find(c=>creatureChoiceLabel(c)===text)||state.creatures.find(c=>c.name===text||c.key===text);
  if(!creature){$('teamCreature').setCustomValidity('请从精灵列表中选择');$('teamCreature').reportValidity();return}
  $('teamCreature').setCustomValidity('');if(plannedTeam.length>=6)return;
  plannedTeam.push({creatureKey:creature.key,skills:[]});$('teamCreature').value='';renderTeamPlanner();
}
function exportPlannedTeam(){
  const payload={format:'roco-world-team',version:1,exportedAt:new Date().toISOString(),members:plannedTeam};
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='洛克王国世界-队伍配置.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}

let captureStream=null,scanTimer=null,actionTimer=null,ocrWorker=null,actionOcrWorker=null,pipWindow=null,recognizing=false,actionRecognizing=false,battleNumber=1,scanCycle=0;
const battleMemory={own:new Map(),enemy:new Map()};
const overlaySelection={attacker:'',defender:'',move:''};
const variableSkillNames=new Set(['取念','复写','借用']);
const isVariableSkill=move=>Boolean(move&&(variableSkillNames.has(move.name)||(move.description||'').includes('巧变')||(move.description||'').includes('随机变成')||(move.description||'').includes('本技能变为')));
function resetBattleMemory(){battleMemory.own.clear();battleMemory.enemy.clear();battleNumber++;$('battleRoundLabel').textContent=`第 ${battleNumber} 局`;renderBattleMemory();$('overlayState').textContent='新一局已开始，技能记录已清空'}
function recordBattleSkills(kind,creature,matches,source='slots'){
  if(!creature||!matches.length)return;
  const allowed=new Set(skillPool(creature,state.moves).map(x=>x.move?.name||x.name));
  if(!battleMemory[kind].has(creature.key))battleMemory[kind].set(creature.key,{name:creature.name,skills:new Set(),baseSkills:new Set(),dynamic:false});
  const entry=battleMemory[kind].get(creature.key),uniqueMatches=[...new Map(matches.map(match=>[match.item.name,match])).values()],raw=uniqueMatches.map(match=>match.item.name);
  if(source==='release'){
    const accepted=uniqueMatches.filter(match=>allowed.has(match.item.name)||match.distance===0);
    if(!accepted.length)return;
    if(accepted.some(match=>!allowed.has(match.item.name)))entry.dynamic=true;
    for(const match of accepted){if(kind==='own'&&entry.skills.size>=4&&!entry.skills.has(match.item.name))continue;entry.skills.add(match.item.name)}
    renderBattleMemory();return;
  }
  if(kind==='own'){
    const poolNames=raw.filter(name=>allowed.has(name));
    if(!entry.baseSkills.size&&poolNames.length)for(const name of poolNames.slice(0,4))entry.baseSkills.add(name);
    if([...entry.baseSkills].some(name=>isVariableSkill(state.moves.find(move=>move.name===name)))||poolNames.some(name=>isVariableSkill(state.moves.find(move=>move.name===name))))entry.dynamic=true;
    const exactOutside=uniqueMatches.filter(match=>match.distance===0&&!allowed.has(match.item.name));if(exactOutside.length&&poolNames.length+exactOutside.length>=2)entry.dynamic=true;
    const current=uniqueMatches.filter(match=>allowed.has(match.item.name)||(entry.dynamic&&match.distance===0)).map(match=>match.item.name).slice(0,4);if(!current.length)return;
    entry.skills=new Set(current);
  }else{
    const accepted=uniqueMatches.filter(match=>allowed.has(match.item.name)||match.distance===0);if(!accepted.length)return;if(accepted.some(match=>!allowed.has(match.item.name)))entry.dynamic=true;for(const match of accepted)entry.skills.add(match.item.name);
  }
  renderBattleMemory();
}
function renderBattleMemory(){
  for(const [kind,id,empty] of [['own','ownSkillMemory','识别画面左侧四个技能槽后自动记录。'],['enemy','enemySkillMemory','识别画面右侧释放提示后按敌方精灵记录。']]){
    const entries=[...battleMemory[kind].entries()];$(id).innerHTML=entries.length?entries.map(([key,entry])=>`<article class="memory-pet"><strong>${escapeHtml(entry.name)}${entry.dynamic?' · 动态技能':''}</strong>${kind==='own'&&entry.baseSkills?.size?`<small>初始：${[...entry.baseSkills].map(escapeHtml).join(' / ')}</small>`:''}<div>${[...entry.skills].map(name=>`<span>${escapeHtml(name)}</span>`).join('')}</div></article>`).join(''):`<p class="muted">${empty}</p>`;
  }
}
function fillOverlaySelectors(){
  const oldAttacker=$('overlayAttacker').value,oldDefender=$('overlayDefender').value;
  const creatures=state.creatures.map((c,i)=>`<option value="${i}">${escapeHtml(c.name)}${c.formName?` · ${escapeHtml(c.formName)}`:''}</option>`).join('');
  $('overlayAttacker').innerHTML='<option value="">请选择</option>'+creatures;
  $('overlayDefender').innerHTML='<option value="">请选择</option>'+creatures;
  $('overlayAttacker').value=oldAttacker;$('overlayDefender').value=oldDefender;
  const oldMove=$('overlayMove').value;
  const attacker=state.creatures[Number($('overlayAttacker').value)];
  const remembered=attacker?battleMemory.own.get(attacker.key)?.skills:null;
  const pool=attacker?skillPool(attacker,state.moves).map(x=>x.move).filter(Boolean).filter(isDamageMove).filter(move=>remembered?.has(move.name)):[];
  $('overlayMove').innerHTML=`<option value="">${remembered?.size?'请选择本局技能':'等待识别本局携带技能'}</option>`+pool.map(m=>`<option value="${state.moves.indexOf(m)}">${escapeHtml(m.name)} · ${escapeHtml(m.type)}系 · ${m.power??'—'}</option>`).join('');
  if([...$('overlayMove').options].some(o=>o.value===oldMove))$('overlayMove').value=oldMove;
}
function updateOverlay(){
  const attacker=state.creatures[Number($('overlayAttacker').value)],defender=state.creatures[Number($('overlayDefender').value)],move=state.moves[Number($('overlayMove').value)];
  if(!attacker||!defender){$('overlayResult').textContent='选择双方精灵和技能后显示伤害。';$('moveRecommendations').innerHTML='<p class="muted">选择双方精灵后生成推荐。</p>';$('floatingDamage').textContent='—';$('floatingMatch').textContent='等待选择精灵与技能';$('floatingBest').textContent='';syncFloatingWindow();return}
  const a=state.attacker.key===attacker.key?clone(state.attacker):buildFromCreature(attacker),d=state.defender.key===defender.key?clone(state.defender):buildFromCreature(defender);
  const currentHp=calculateStats(d).hp*Number($('targetHpPercent').value)/100;
  const ranked=skillPool(attacker,state.moves).map(x=>x.move).filter(Boolean).filter(isDamageMove).map(candidate=>({move:candidate,result:calculateDamage(a,d,candidate,state.chart,{})})).sort((x,y)=>y.result.damage-x.result.damage);
  $('moveRecommendations').innerHTML=ranked.slice(0,8).map((item,index)=>{const lethal=item.result.damage>=currentHp,turns=Math.max(1,Math.ceil(currentHp/item.result.damage)),rule=item.result.factors.powerRule;return `<button data-recommend-move="${state.moves.indexOf(item.move)}" class="recommend-row ${move===item.move?'active':''}"><b>${index+1}</b><span><strong>${escapeHtml(item.move.name)}</strong><small>${escapeHtml(item.move.type)}系 · ${rule?`${powerRuleLabel(rule)} → 威力 ${rule.power} · `:''}${item.result.hpPercent.toFixed(1)}% 总生命</small></span><em>${item.result.damage}</em><i class="${lethal?'lethal':''}">${lethal?'可击败':`${turns} 次`}</i></button>`}).join('')||'<p class="muted">当前技能池没有可直接计算伤害的技能。</p>';
  $('moveRecommendations').querySelectorAll('[data-recommend-move]').forEach(button=>button.onclick=()=>{$('overlayMove').value=button.dataset.recommendMove;updateOverlay()});
  const best=ranked[0];$('floatingBest').textContent=best?`推荐：${best.move.name} · ${best.result.damage}${best.result.damage>=currentHp?' · 可击败':''}`:'';
  if(!move){$('overlayResult').textContent='请选择一个技能；下方已经按预计伤害排序。';$('floatingDamage').textContent=best?String(best.result.damage):'—';$('floatingMatch').textContent=best?`${attacker.name} · ${best.move.name} → ${defender.name}`:'没有可计算技能';$('floatingFactors').textContent='当前显示推荐技能的预计伤害';syncFloatingWindow();return}
  const r=calculateDamage(a,d,move,state.chart,{});
  const text=`${attacker.name} · ${move.name} → ${defender.name}`;
  const lethal=r.damage>=currentHp;
  $('overlayResult').innerHTML=`<small>${escapeHtml(text)}</small><div class="big">${r.damage}</div><div>${r.factors.powerRule?`${powerRuleLabel(r.factors.powerRule)} → 实际威力 ${r.factors.power} · `:''}预计 ${r.hpPercent.toFixed(1)}% 总生命 · 本系 ×${r.factors.stab} · 克制 ×${r.factors.type}${lethal?' · <b>可击败当前血量目标</b>':` · 约需 ${Math.ceil(currentHp/r.damage)} 次`}</div>`;
  $('floatingDamage').textContent=String(r.damage);$('floatingMatch').textContent=text;$('floatingFactors').textContent=`约 ${r.hpPercent.toFixed(1)}% 生命 · 克制 ×${r.factors.type}`;syncFloatingWindow();
}
function floatingPayload(){return{damage:$('floatingDamage').textContent,match:$('floatingMatch').textContent,factors:$('floatingFactors').textContent,best:$('floatingBest').textContent}}
function syncFloatingWindow(){window.rocoDesktop?.updateOverlay(floatingPayload())}
function editDistance(a,b){const row=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){let diagonal=row[0];row[0]=i;for(let j=1;j<=b.length;j++){const old=row[j];row[j]=Math.min(row[j]+1,row[j-1]+1,diagonal+(a[i-1]===b[j-1]?0:1));diagonal=old}}return row[b.length]}
function fuzzyFind(text,items,nameOf){
  const clean=String(text).replace(/[\s\p{P}\p{S}]/gu,'');
  return items.map((item,index)=>{const name=nameOf(item).replace(/\s/g,'');if(name.length<2)return null;if(clean.includes(name))return{item,index,name,distance:0};if(name.length<3||clean.length<2)return null;let best=99;for(const length of [name.length-1,name.length,name.length+1])for(let start=0;start<=clean.length-length;start++)best=Math.min(best,editDistance(name,clean.slice(start,start+length)));return best<=Math.max(1,Math.floor(name.length*.25))?{item,index,name,distance:best}:null}).filter(Boolean).sort((a,b)=>a.distance-b.distance||b.name.length-a.name.length);
}
async function loadOcr(){
  if(ocrWorker)return ocrWorker;
  $('overlayState').textContent='正在加载中文画面识别…';
  if(!window.Tesseract){await new Promise((resolve,reject)=>{const s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';s.onload=resolve;s.onerror=()=>reject(Error('识别组件下载失败'));document.head.appendChild(s)})}
  ocrWorker=await window.Tesseract.createWorker('chi_sim+eng',1,{logger:m=>{if(m.status==='recognizing text')$('overlayState').textContent=`正在识别画面 ${Math.round(m.progress*100)}%`}});
  return ocrWorker;
}
async function loadActionOcr(){
  if(actionOcrWorker)return actionOcrWorker;
  await loadOcr();
  actionOcrWorker=await window.Tesseract.createWorker('chi_sim+eng');
  return actionOcrWorker;
}
async function recognizeVideoRegion(worker,video,canvas,left,top,right,bottom,maxWidth=1280){
  const sourceX=Math.round(video.videoWidth*left),sourceY=Math.round(video.videoHeight*top),sourceW=Math.max(1,Math.round(video.videoWidth*(right-left))),sourceH=Math.max(1,Math.round(video.videoHeight*(bottom-top))),scale=Math.min(1,maxWidth/sourceW);
  canvas.width=Math.round(sourceW*scale);canvas.height=Math.round(sourceH*scale);const context=canvas.getContext('2d');context.filter='grayscale(1) contrast(1.65)';context.drawImage(video,sourceX,sourceY,sourceW,sourceH,0,0,canvas.width,canvas.height);context.filter='none';
  return (await worker.recognize(canvas)).data.text;
}
async function scanActionBanners(){
  if(!captureStream||actionRecognizing||!$('capturePreview').videoWidth)return;
  actionRecognizing=true;
  try{
    const video=$('capturePreview'),canvas=$('actionBannerCanvas'),worker=await loadActionOcr();
    const sourceY=Math.round(video.videoHeight*.12),sourceH=Math.round(video.videoHeight*.17),scale=Math.min(1,1600/video.videoWidth);
    canvas.width=Math.round(video.videoWidth*scale);canvas.height=Math.round(sourceH*scale);
    const context=canvas.getContext('2d');context.filter='grayscale(1) contrast(1.8)';context.drawImage(video,0,sourceY,video.videoWidth,sourceH,0,0,canvas.width,canvas.height);context.filter='none';
    const result=(await worker.recognize(canvas)).data,mid=canvas.width/2,words=result.words||[],allText=result.text||'';
    const leftText=words.length?words.filter(word=>(word.bbox.x0+word.bbox.x1)/2<mid).map(word=>word.text).join(' '):allText;
    const rightText=words.length?words.filter(word=>(word.bbox.x0+word.bbox.x1)/2>=mid).map(word=>word.text).join(' '):allText;
    const attacker=state.creatures[Number($('overlayAttacker').value)],defender=state.creatures[Number($('overlayDefender').value)];
    const ownMoves=fuzzyFind(leftText,state.moves,move=>move.name),enemyMoves=fuzzyFind(rightText,state.moves,move=>move.name);
    if(ownMoves.length)recordBattleSkills('own',attacker,ownMoves,'release');
    if(enemyMoves.length)recordBattleSkills('enemy',defender,enemyMoves,'release');
    const released=ownMoves.find(match=>isDamageMove(match.item));
    if(released&&attacker){fillOverlaySelectors();const option=[...$('overlayMove').options].find(item=>Number(item.value)===released.index);if(option)$('overlayMove').value=option.value;updateOverlay()}
    if(ownMoves.length||enemyMoves.length)$('overlayState').textContent=`捕获释放提示 · 己方 ${ownMoves[0]?.item.name||'—'} · 敌方 ${enemyMoves[0]?.item.name||'—'}`;
  }catch(error){console.warn('释放提示识别失败',error)}finally{actionRecognizing=false}
}
function scheduleActionScan(){clearTimeout(actionTimer);if(captureStream)actionTimer=setTimeout(async()=>{await scanActionBanners();scheduleActionScan()},650)}
async function loadCaptureSources(){
  const select=$('captureSource'),button=$('refreshCaptureSources');
  if(!window.rocoDesktop?.listCaptureSources){select.innerHTML='<option value="">网页模式：请在浏览器共享窗口中选择游戏</option>';button.disabled=true;return}
  button.disabled=true;select.innerHTML='<option value="">正在读取窗口…</option>';
  try{
    const sources=await window.rocoDesktop.listCaptureSources(),previous=select.value;
    select.innerHTML='<option value="">请选择《洛克王国：世界》窗口</option>'+sources.map(source=>`<option value="${escapeHtml(source.id)}">${source.kind==='screen'?'整个屏幕':'窗口'} · ${escapeHtml(source.name)}</option>`).join('');
    const game=sources.find(source=>/洛克王国|roco\s*kingdom/i.test(source.name));select.value=sources.some(source=>source.id===previous)?previous:(game?.id||'');
    $('overlayState').textContent=game?'已找到游戏窗口，请确认后开始识别':'未自动找到游戏窗口，请从列表手动选择或刷新';
  }catch(error){select.innerHTML='<option value="">窗口列表读取失败</option>';$('overlayState').textContent=`读取窗口失败：${error.message}`}
  finally{button.disabled=false}
}
async function scanFrame(){
  if(!captureStream||recognizing||!$('capturePreview').videoWidth)return;
  recognizing=true;
  try{
    scanCycle++;const video=$('capturePreview'),top=Number($('cropTop').value)/100,bottom=Number($('cropBottom').value)/100,worker=await loadOcr();
    const text=scanCycle===1||scanCycle%4===0?await recognizeVideoRegion(worker,video,$('captureCanvas'),0,top,1,bottom,1100):'';
    const compact=text.replace(/\s+/g,' ').trim();if(text)$('ocrText').textContent=compact?`识别文字：${compact.slice(0,240)}`:'本轮没有识别到精灵文字；技能区域仍在单独识别。';
    const creatures=fuzzyFind(text,state.creatures,c=>c.name),portraits=scanCycle===1||scanCycle%4===0?recognizeBattlePortraits(video):{};
    // 玩家昵称可以自由修改，优先使用顶部头像建模；头像库尚未就绪时才以文字作辅助。
    if(!portraits.own&&creatures[0]){$('overlayAttacker').value=String(creatures[0].index);fillOverlaySelectors();$('overlayAttacker').value=String(creatures[0].index)}
    if(!portraits.enemy&&creatures[1])$('overlayDefender').value=String(creatures.find(x=>x.index!==creatures[0].index)?.index??'');
    const attacker=state.creatures[Number($('overlayAttacker').value)],defender=state.creatures[Number($('overlayDefender').value)];
    const ownText=await recognizeVideoRegion(worker,video,$('ownSkillCanvas'),Number($('ownSkillLeft').value)/100,Number($('ownSkillTop').value)/100,Number($('ownSkillRight').value)/100,Number($('ownSkillBottom').value)/100,720);
    recordBattleSkills('own',attacker,fuzzyFind(ownText,state.moves,m=>m.name));
    if(scanCycle%2===0){const enemyText=await recognizeVideoRegion(worker,video,$('enemySkillCanvas'),0,0,1,.45,900);recordBattleSkills('enemy',defender,fuzzyFind(enemyText,state.moves,m=>m.name))}
    fillOverlaySelectors();const carried=battleMemory.own.get(attacker?.key)?.skills;if(carried?.size&&!$('overlayMove').value){const detected=fuzzyFind(ownText,state.moves,m=>m.name).find(match=>carried.has(match.item.name)&&isDamageMove(match.item));if(detected)$('overlayMove').value=String(detected.index)}
    $('floatingStatus').textContent=`识别于 ${new Date().toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}`;
    $('overlayState').textContent=`持续识别中 · ${portraits.own||portraits.enemy?'头像建模已匹配':'头像模型准备中'}，本局记录已更新`;updateOverlay();
  }catch(error){$('overlayState').textContent=`识别失败：${error.message}`}
  finally{recognizing=false}
}
async function startCapture(){
  try{
    if(window.rocoDesktop?.selectCaptureSource){if(!$('captureSource').value){$('overlayState').textContent='请先从列表选择《洛克王国：世界》窗口';return}await window.rocoDesktop.selectCaptureSource($('captureSource').value)}
    captureStream=await navigator.mediaDevices.getDisplayMedia({video:{frameRate:5},audio:false});$('capturePreview').srcObject=captureStream;
    $('startCapture').disabled=true;$('stopCapture').disabled=false;$('overlayState').textContent='已连接，准备识别…';
    captureStream.getVideoTracks()[0].addEventListener('ended',stopCapture);await new Promise(r=>$('capturePreview').onloadedmetadata=r);await scanFrame();scheduleScan();scheduleActionScan();
  }catch(error){$('overlayState').textContent=error.name==='NotAllowedError'?'已取消选择游戏窗口':`无法读取画面：${error.message}`}
}
function scheduleScan(){clearTimeout(scanTimer);if(captureStream)scanTimer=setTimeout(async()=>{await scanFrame();scheduleScan()},Math.max(1,Number($('scanInterval').value)||2)*1000)}
function stopCapture(){clearTimeout(scanTimer);clearTimeout(actionTimer);captureStream?.getTracks().forEach(t=>t.stop());captureStream=null;$('capturePreview').srcObject=null;$('startCapture').disabled=false;$('stopCapture').disabled=true;$('overlayState').textContent='画面识别已停止'}
async function openFloatingWindow(){
  const card=$('floatingCard');
  if(window.rocoDesktop?.openOverlay){await window.rocoDesktop.openOverlay(floatingPayload());$('overlayState').textContent='原生置顶悬浮窗已打开，可拖动和缩放';return}
  if('documentPictureInPicture' in window){pipWindow=await window.documentPictureInPicture.requestWindow({width:390,height:230});const style=document.createElement('style');style.textContent=`body{margin:0;background:#071827;color:#eef9f6;font-family:system-ui}.floating-card{display:block!important;padding:22px;box-sizing:border-box}.floating-top{display:flex;justify-content:space-between;color:#5ee2b8}.floating-card>strong{display:block;font-size:64px;line-height:1;margin:16px 0 8px}.floating-card p{margin:0 0 12px;font-weight:700}.floating-card small{color:#a8c6c0}`;pipWindow.document.head.append(style);pipWindow.document.body.append(card);pipWindow.addEventListener('pagehide',()=>document.getElementById('overlay').append(card),{once:true})}
  else{alert('当前浏览器不支持置顶画中画，请使用最新版 Chrome 或 Edge。')}
}
async function loadCatalog(){
  try{const [pokemon,skills,icons,eggs,groups]=await Promise.all([fetch('data/pokemon.json').then(r=>{if(!r.ok)throw Error('精灵库加载失败');return r.json()}),fetch('data/skills.json').then(r=>{if(!r.ok)throw Error('技能库加载失败');return r.json()}),fetch('data/wiki-icons.json').then(r=>r.json()),fetch('data/eggs.json').then(r=>{if(!r.ok)throw Error('蛋资料加载失败');return r.json()}),fetch('data/egg-groups.json').then(r=>r.json())]);
    imageMaps={pets:icons.pets,skills:icons.skills};
    eggData=eggs;eggGroups=groups;$('eggGroup').innerHTML='<option value="">全部蛋组</option>'+[...new Set(Object.values(groups).flat())].sort((a,b)=>a.localeCompare(b,'zh')).map(g=>`<option value="${escapeHtml(g)}">${escapeHtml(g)}</option>`).join('');$('eggCount').textContent=`${eggs.length} 种蛋重 · ${eggs.filter(e=>e.heightMin!=null).length} 种蛋径`;renderEggs();
    state.creatures=pokemon.map(normalizeCreature);state.moves=skills.map(normalizeMove);buildPortraitIndex();
    renderBuild('attacker');renderBuild('defender');renderMoveLibrary();renderCatalog();fillOverlaySelectors();renderTeamPlanner();update();
  }catch(e){$('catalogCount').textContent=`图鉴加载失败：${e.message}`}
}
function showDataVersion(){fetch(`data/version.json?t=${Date.now()}`).then(r=>r.ok?r.json():null).then(v=>{if(v){$('dataVersion').textContent=`最近同步：${new Date(v.syncedAt).toLocaleString('zh-CN')}${v.counts?` · ${v.counts.creatures} 条精灵形态 · ${v.counts.skills} 个技能`:''}`;if($('homeDataVersion'))$('homeDataVersion').textContent=`更新于 ${new Date(v.syncedAt).toLocaleDateString('zh-CN')}`}}).catch(()=>{})}
showDataVersion();

for(const id of ['moveType'])$(id).innerHTML=typeOptions('普通');
$('profileType0').innerHTML=typeOptions('草');$('profileType1').innerHTML=typeOptions('',true);
renderTypePickers();
renderBuild('attacker');renderBuild('defender');renderChart();renderMoveLibrary();
renderDefensiveProfile();
for(const id of ['creatureType','skillType'])$(id).innerHTML='<option value="">全部属性</option>'+typeOptions();
for(const id of ['creatureSearch','creatureType','eggGroup','creatureStage','creatureSort','skillSearch','skillType','skillCategory','skillTag'])$(id).addEventListener('input',()=>{pages[id.startsWith('skill')?'skill':'creature']=1;renderCatalog()});
for(const kind of ['creature','skill']){ $(`${kind}Prev`).onclick=()=>{pages[kind]--;renderCatalog();$(`${kind}List`).scrollTop=0};$(`${kind}Next`).onclick=()=>{pages[kind]++;renderCatalog();$(`${kind}List`).scrollTop=0} }
for(const id of ['eggHeight','eggWeight'])$(id).addEventListener('input',renderEggs);
$('overlayAttacker').addEventListener('change',()=>{fillOverlaySelectors();updateOverlay()});
$('overlayDefender').addEventListener('change',updateOverlay);$('overlayMove').addEventListener('change',updateOverlay);
$('targetHpPercent').addEventListener('input',()=>{$('targetHpValue').textContent=`${$('targetHpPercent').value}%`;updateOverlay()});
$('startCapture').onclick=startCapture;$('stopCapture').onclick=stopCapture;$('openOverlay').onclick=()=>openFloatingWindow().catch(error=>$('overlayState').textContent=`无法打开悬浮窗：${error.message}`);
$('refreshCaptureSources').onclick=loadCaptureSources;
$('newBattle').onclick=resetBattleMemory;renderBattleMemory();
for(const id of ['cropTop','cropBottom','ownSkillLeft','ownSkillRight','ownSkillTop','ownSkillBottom'])$(id).addEventListener('input',()=>{$(`${id}Value`).textContent=`${$(id).value}%`});
$('creatureList').onclick=e=>{const card=e.target.closest('[data-key]');if(!card)return;selectedCreature=card.dataset.key;renderCatalog();showCreature()};
$('skillList').onclick=e=>{const card=e.target.closest('[data-name]');if(!card)return;selectedSkill=card.dataset.name;renderCatalog();showSkill()};
for(const id of ['moveName','moveType','category','power','moveEnergy','hits','attackStage','defenseStage','extra','reduction','rain','aHpMod','aAtkMod','aDefMod','aMatkMod','aMdefMod','aSpeedMod','dHpMod','dAtkMod','dDefMod','dMatkMod','dMdefMod','dSpeedMod','aAtkLayers','aAtkLayerPct','aMatkLayers','aMatkLayerPct','aDefLayers','aDefLayerPct','aMdefLayers','aMdefLayerPct','aSpeedLayers','aSpeedLayerPct','dAtkLayers','dAtkLayerPct','dMatkLayers','dMatkLayerPct','dDefLayers','dDefLayerPct','dMdefLayers','dMdefLayerPct','dSpeedLayers','dSpeedLayerPct','starLayers','freezeLayers','poisonLayers','cuteLayers','enemyBuffLayers','powerAdd','powerPercent','comboAdd','counterStatus','selfDebuffed'])$(id).addEventListener('input',update);
$('calcTargetHp').addEventListener('input',()=>{$('calcTargetHpValue').textContent=`${$('calcTargetHp').value}%`;update()});
$('battlePreset').addEventListener('change',renderBattlePresets);$('saveBattle').onclick=saveBattlePreset;$('loadBattle').onclick=loadBattlePreset;
$('deleteBattle').onclick=()=>{const id=$('battlePreset').value;if(!id)return;battlePresets=battlePresets.filter(item=>String(item.id)!==id);localStorage.setItem('roco-battle-presets',JSON.stringify(battlePresets));renderBattlePresets()};
$('swap').onclick=()=>{[state.attacker,state.defender]=[state.defender,state.attacker];renderBuild('attacker');renderBuild('defender');renderMoveLibrary();update()};
$('resetChart').onclick=()=>{state.chart=clone(defaultChart);renderChart();renderDefensiveProfile();update()};
$('typeTable').onclick=e=>{const c=e.target.closest('td[data-at]');if(!c)return;const {at,dt}=c.dataset;const values=[1,2,.5,0,3,.25];const current=state.chart[at]?.[dt]??1;state.chart[at]||={};state.chart[at][dt]=values[(values.indexOf(current)+1)%values.length];renderChart();renderDefensiveProfile();update()};
for(const id of ['profileType0','profileType1'])$(id).addEventListener('change',()=>{renderTypePickers();renderDefensiveProfile()});
$('homeSearch').addEventListener('input',e=>{const q=e.target.value.trim().toLowerCase();let visible=0;document.querySelectorAll('#homeNav a').forEach(card=>{const show=!q||`${card.textContent} ${card.dataset.keywords}`.toLowerCase().includes(q);card.hidden=!show;if(show)visible++});$('homeEmpty').hidden=visible>0});
$('addTeamMember').onclick=addTeamMember;$('teamCreature').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();addTeamMember()}});
$('teamMembers').addEventListener('change',e=>{const select=e.target.closest('[data-team-skill]');if(!select)return;const member=plannedTeam[Number(select.dataset.teamSkill)];if(!member)return;member.skills[Number(select.dataset.slot)]=select.value;member.skills=[...new Set(member.skills.filter(Boolean))].slice(0,4);renderTeamPlanner()});
$('teamMembers').addEventListener('click',e=>{const remove=e.target.closest('.remove-team-member');if(remove){plannedTeam.splice(Number(remove.dataset.index),1);renderTeamPlanner();return}const use=e.target.closest('.use-team-attacker');if(use){const member=plannedTeam[Number(use.dataset.index)],creature=state.creatures.find(c=>c.key===member?.creatureKey);if(creature){useCreature('attacker',creature);navigateView('calculator')}}});
$('teamRecommendations').addEventListener('click',e=>{const button=e.target.closest('[data-recommend-key]');if(!button||plannedTeam.length>=6)return;plannedTeam.push({creatureKey:button.dataset.recommendKey,skills:[]});renderTeamPlanner()});
$('exportTeam').onclick=exportPlannedTeam;
$('importTeam').onchange=async e=>{try{const parsed=JSON.parse(await e.target.files[0].text()),members=parsed.members??parsed;plannedTeam=sanitizeTeam(members,state.creatures,state.moves,skillPool);if(!plannedTeam.length&&Array.isArray(members)&&members.length)throw Error('没有找到与当前图鉴匹配的精灵');renderTeamPlanner()}catch(error){alert(`队伍导入失败：${error.message}`)}finally{e.target.value=''}};
$('clearTeam').onclick=()=>{plannedTeam=[];renderTeamPlanner()};
$('movePreset').onchange=e=>{const move=state.moves.find(item=>item.name===e.target.value);if(move)setMove(move)};
$('importFile').onchange=async e=>{try{const data=JSON.parse(await e.target.files[0].text());if(data.creatures){if(!Array.isArray(data.creatures)||!data.creatures.every(validCreature))throw Error('精灵数据格式无效');state.creatures=data.creatures}if(data.moves){if(!Array.isArray(data.moves)||!data.moves.every(validMove))throw Error('技能数据格式无效');state.moves=data.moves;renderMoveLibrary()}if(data.typeChart){if(!validChart(data.typeChart))throw Error('属性表格式无效');state.chart=data.typeChart;renderChart();renderDefensiveProfile()}if(data.attacker&&data.defender){state.attacker=data.attacker;state.defender=data.defender}renderBuild('attacker');renderBuild('defender');renderCatalog();$('importStatus').textContent=`已导入 ${state.creatures.length} 只精灵、${state.moves.length} 个技能`;update()}catch(err){$('importStatus').textContent=`导入失败：${err.message}`}};
$('exportButton').onclick=()=>{const blob=new Blob([JSON.stringify({...state,move:readMove()},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='roco-world-config.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)};
$('clearSaved').onclick=()=>{localStorage.removeItem('roco-world-state');location.reload()};
$('syncData').onclick=async()=>{
  const button=$('syncData'),status=$('syncStatus');button.disabled=true;button.textContent='正在更新…';status.className='muted';status.textContent='正在下载并整理资料，通常需要几秒钟。';
  try{const response=await fetch('/api/sync',{method:'POST'});const result=await response.json();if(!response.ok)throw Error(result.message||'更新失败');status.className='sync-success';status.textContent='更新完成，正在重新载入最新资料…';showDataVersion();setTimeout(()=>location.reload(),900)}
  catch(error){status.className='sync-error';status.textContent=error.message||'更新失败，请检查网络连接后重试。';button.disabled=false;button.textContent='重新更新'}
};
update();
renderBattlePresets();
loadCaptureSources();
loadCatalog();
window.addEventListener('hashchange',()=>showView(location.hash.slice(1)));
showView(location.hash.slice(1));
