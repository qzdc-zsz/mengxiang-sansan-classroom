export const TYPES = ['普通','草','火','水','光','地','冰','龙','电','毒','虫','武','翼','萌','幽','恶','机械','幻'];
export const STATS = ['hp','atk','def','matk','mdef','speed'];
export const STAT_NAMES = {hp:'生命',atk:'物攻',def:'物防',matk:'魔攻',mdef:'魔防',speed:'速度'};

export function validateBuild(build) {
  if (!build || !Array.isArray(build.types) || build.types.length < 1 || build.types.length > 2 || new Set(build.types).size !== build.types.length) throw Error('精灵必须有 1～2 个不同属性');
  if (build.types.some(t => !TYPES.includes(t))) throw Error('存在未知精灵属性');
  let invested = 0;
  for (const key of STATS) {
    const base = Number(build.base?.[key]), iv = Number(build.iv?.[key]);
    if (!Number.isInteger(base) || base < 0 || base > 999) throw Error(`${STAT_NAMES[key]}种族值须为 0～999 的整数`);
    if (!Number.isInteger(iv) || iv < 0 || iv > 10) throw Error(`${STAT_NAMES[key]}个体须为 0～10 的整数`);
    if (iv > 0) invested++;
  }
  if (invested > 3) throw Error('最多只能给 3 项能力分配个体值');
  if (build.nature?.up && (!STATS.includes(build.nature.up) || build.nature.up === build.nature.down)) throw Error('性格提升项无效');
  if (build.nature?.down && !STATS.includes(build.nature.down)) throw Error('性格降低项无效');
}

// 社区公式：个体输入 0～10，计算时每点折合 3 种族值。
export function calculateStats(build) {
  validateBuild(build);
  return Object.fromEntries(STATS.map(key => {
    const core = build.base[key] + 3 * build.iv[key];
    const rounded = Math.round((key === 'hp' ? 1.7 : 1.1) * core + (key === 'hp' ? 70 : 10));
    const nature = key === build.nature?.up ? 1.2 : key === build.nature?.down ? 0.9 : 1;
    return [key, Math.floor(rounded * nature + (key === 'hp' ? 100 : 50))];
  }));
}

export function effectiveness(moveType, defenderTypes, chart) {
  if (!TYPES.includes(moveType) || !Array.isArray(defenderTypes) || defenderTypes.some(t => !TYPES.includes(t))) throw Error('属性无效');
  const parts = defenderTypes.map(t => Number(chart?.[moveType]?.[t] ?? 1));
  if (parts.some(x => ![0,0.25,0.5,1,2,3].includes(x))) throw Error('克制倍率无效');
  if (parts.includes(0)) return 0;
  if (parts.length === 2 && parts.every(x => x === 2)) return 3;
  return parts.reduce((a,b) => a*b, 1);
}
export function defensiveProfile(defenderTypes, chart){
  if(!Array.isArray(defenderTypes)||defenderTypes.length<1||defenderTypes.length>2||new Set(defenderTypes).size!==defenderTypes.length)throw Error('请选择一到两个不同属性');
  return Object.fromEntries(TYPES.map(type=>[type,effectiveness(type,defenderTypes,chart)]));
}

// S2 属性差阶梯：1～120 每 30 点 +20；121 起每 30 点 +10；上限威力 200。
// 规则同时用于闪击（速度差）与鸣沙陷阱（物防差）。
export function differenceMovePower(moveName, attackerStats, defenderStats) {
  const stat = moveName === '闪击' ? 'speed' : moveName === '鸣沙陷阱' ? 'def' : '';
  if (!stat) return null;
  const difference = attackerStats[stat] - defenderStats[stat];
  if (difference <= 0) return { power: 60, stat, difference, rule: `${STAT_NAMES[stat]}差` };
  const add = difference <= 120
    ? Math.ceil(difference / 30) * 20
    : Math.min(140, 80 + Math.ceil((difference - 120) / 30) * 10);
  return { power: 60 + add, stat, difference, rule: `${STAT_NAMES[stat]}差` };
}

export function manaBurstPower(energy) {
  const table=[45,70,90,110,135,155,165,180,190,200,210],value=Number(energy);
  if(!Number.isInteger(value)||value<0||value>10)throw Error('剩余能量须为 0～10 的整数');
  return table[value];
}

function numberOption(value, fallback=0) {
  const n=Number(value??fallback);
  return Number.isFinite(n)?n:fallback;
}

// 战斗中的增减益按最终面板属性结算。正数为增益，负数为减益；flat 用于速度+5等固定变化。
export function applyBattleModifiers(stats, modifiers={}, layerModifiers={}) {
  return Object.fromEntries(STATS.map(key=>{
    const layer=layerModifiers?.[key]||{},layers=numberOption(layer.layers),perLayer=numberOption(layer.percent),percent=numberOption(modifiers?.[key],0)+layers*perLayer,flat=numberOption(modifiers?.flat?.[key],0)+layers*numberOption(layer.flat);
    if(!Number.isInteger(layers)||layers < -20 || layers > 20 || perLayer < -500 || perLayer > 500)throw Error(`${STAT_NAMES[key]}层数或每层幅度无效`);
    if(percent < -100 || percent > 500 || flat < -9999 || flat > 9999) throw Error(`${STAT_NAMES[key]}增减益超出范围`);
    return [key,Math.max(key==='hp'?1:0,Math.floor(stats[key]*(1+percent/100)+flat))];
  }));
}

export function resolveMoveState(move, options={}) {
  let power=Number(move.power),hits=numberOption(options.hits,1);
  const notes=[],starLayers=Math.max(0,Math.floor(numberOption(options.starLayers))),freezeLayers=Math.max(0,Math.floor(numberOption(options.freezeLayers))),poisonLayers=Math.max(0,Math.floor(numberOption(options.poisonLayers))),cuteLayers=Math.max(0,Math.floor(numberOption(options.cuteLayers))),enemyBuffLayers=Math.max(0,Math.floor(numberOption(options.enemyBuffLayers)));
  const counter=!!options.counterStatus,selfDebuffed=!!options.selfDebuffed;
  if([starLayers,freezeLayers,poisonLayers,cuteLayers,enemyBuffLayers].some(x=>x>99))throw Error('叠层须为 0～99');
  if(move.name==='碎冰冰'){power+=freezeLayers*20;notes.push(`冻结 ${freezeLayers} 层：威力 +${freezeLayers*20}`)}
  if(move.name==='鸩毒'){const add=poisonLayers*(counter?20:10);power+=add;notes.push(`中毒 ${poisonLayers} 层：威力 +${add}`)}
  if(move.name==='天体吸积'){power+=starLayers*20;notes.push(`星陨 ${starLayers} 层：威力 +${starLayers*20}`)}
  if(move.name==='多维击打'){hits+=starLayers;notes.push(`星陨 ${starLayers} 层：连击 +${starLayers}`)}
  if(move.name==='月光合奏'){hits+=cuteLayers;notes.push(`双方萌化 ${cuteLayers} 层：连击 +${cuteLayers}`)}
  if(move.name==='变形活画'){power*=1+enemyBuffLayers*.1;notes.push(`敌方增益 ${enemyBuffLayers} 层：威力 +${enemyBuffLayers*10}%`)}
  if(move.name==='急中生智'&&selfDebuffed){power+=40;notes.push('自身存在减益：威力 +40')}
  const counters={偷袭:3,突袭:3,无影脚:2,爆冲:5,技巧打击:10,闪燃:4,龙卷风:1.5,虫击:2,滚雪球:2,吹炎:2,地陷:2};
  if(counter&&counters[move.name]){power*=counters[move.name];notes.push(`应对状态：威力 ×${counters[move.name]}`)}
  if(counter&&move.name==='散手'){hits=6;notes.push('应对状态：改为 6 连击')}
  if(counter&&move.name==='连续爪击'){hits*=2;notes.push('应对状态：连击翻倍')}
  const powerAdd=numberOption(options.powerAdd),powerPercent=numberOption(options.powerPercent),comboAdd=numberOption(options.comboAdd);
  if(powerAdd < -9999 || powerAdd > 9999 || powerPercent < -100 || powerPercent > 1000 || comboAdd < -20 || comboAdd > 100)throw Error('技能增减益超出范围');
  power=(power+powerAdd)*(1+powerPercent/100);hits+=comboAdd;
  power=Math.max(0,Math.round(power));hits=Math.max(1,Math.floor(hits));
  if(hits>120)throw Error('最终连击数不能超过 120');
  if(powerAdd)notes.push(`技能威力 ${powerAdd>0?'+':''}${powerAdd}`);
  if(powerPercent)notes.push(`技能威力 ${powerPercent>0?'+':''}${powerPercent}%`);
  if(comboAdd)notes.push(`连击 ${comboAdd>0?'+':''}${comboAdd}`);
  return {power,hits,notes,starLayers};
}

export function calculateDamage(attacker, defender, move, chart, options = {}) {
  const baseA=calculateStats(attacker),baseD=calculateStats(defender),a=applyBattleModifiers(baseA,options.attackerModifiers,options.attackerLayers),d=applyBattleModifiers(baseD,options.defenderModifiers,options.defenderLayers);
  if (!TYPES.includes(move.type)) throw Error('技能属性无效');
  if (!['physical','magic'].includes(move.category)) throw Error('技能类型无效');
  if (!Number.isFinite(move.power) || move.power < 0 || move.power > 9999) throw Error('威力须为 0～9999');
  const requestedHits=Number(options.hits ?? 1);
  if (!Number.isInteger(requestedHits) || requestedHits < 1 || requestedHits > 20) throw Error('基础连击次数须为 1～20');
  const attack = move.category === 'physical' ? a.atk : a.matk;
  const defense = move.category === 'physical' ? d.def : d.mdef;
  const type = effectiveness(move.type, defender.types, chart);
  const stab = attacker.types.includes(move.type) ? 1.25 : 1;
  const weather = options.rain && move.type === '水' ? 1.5 : 1;
  const attackStage = Number(options.attackStage ?? 0), defenseStage = Number(options.defenseStage ?? 0);
  if (![attackStage,defenseStage].every(x => Number.isInteger(x) && x >= -6 && x <= 6)) throw Error('能力等级须为 -6～6');
  const stage = (1 + Math.max(attackStage,0) + Math.max(-defenseStage,0)) / (1 + Math.max(-attackStage,0) + Math.max(defenseStage,0));
  const extra = Number(options.extraMultiplier ?? 1), reduction = Number(options.reduction ?? 0);
  if (!Number.isFinite(extra) || extra < 0 || extra > 100 || !Number.isFinite(reduction) || reduction < 0 || reduction > 1) throw Error('额外倍率或减伤无效');
  const differenceRule = differenceMovePower(move.name, a, d);
  const manaRule = move.name==='魔能爆'?{power:manaBurstPower(options.energy??10),energy:Number(options.energy??10),rule:'消耗能量'}:null;
  const powerRule=differenceRule||manaRule,dynamicMove=resolveMoveState({...move,power:powerRule?.power??move.power},options),effectivePower=dynamicMove.power,hits=dynamicMove.hits;
  const raw = defense ? attack / defense * (37/41) * effectivePower * stage * stab * type * weather * extra * (1-reduction) : 0;
  const perHit = type === 0 ? 0 : Math.max(1, Math.floor(raw));
  const skillDamage=perHit*hits;
  let starDamage=0,starPower=0,starType=1;
  if(dynamicMove.starLayers>0&&move.type!=='幻'){
    starPower=dynamicMove.starLayers**2+24*dynamicMove.starLayers-24;
    starType=effectiveness('幻',defender.types,chart);
    const starRaw=defense?attack/defense*(37/41)*starPower*stage*starType*weather*extra*(1-reduction):0;
    starDamage=starType===0?0:Math.max(1,Math.floor(starRaw));
    dynamicMove.notes.push(`星陨 ${dynamicMove.starLayers} 层：追加 ${starDamage} 伤害`);
  }
  const damage=skillDamage+starDamage;
  return {damage,skillDamage,starDamage,perHit,hits,attackerStats:a,defenderStats:d,baseAttackerStats:baseA,baseDefenderStats:baseD,notes:dynamicMove.notes,factors:{attack,defense,power:effectivePower,powerRule,stab,type,stage,weather,extra,reduction,starPower,starType},hpPercent:d.hp?damage/d.hp*100:0};
}
