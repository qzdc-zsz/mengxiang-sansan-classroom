export function analyzeTeam(members, creatures, moves, chart, effectiveness) {
  const creatureMap = new Map(creatures.map(creature => [creature.key, creature]));
  const moveMap = new Map(moves.map(move => [move.name, move]));
  const attackTypes = new Set();
  const weaknesses = new Map();
  const resistances = new Map();
  for (const member of members) {
    const creature = creatureMap.get(member.creatureKey);
    if (!creature) continue;
    for (const name of member.skills || []) {
      const move = moveMap.get(name);
      if (move && move.power > 0) attackTypes.add(move.type);
    }
    for (const attackType of Object.keys(chart)) {
      const factor = effectiveness(attackType, creature.types, chart);
      if (factor > 1) weaknesses.set(attackType, (weaknesses.get(attackType) || 0) + 1);
      if (factor < 1) resistances.set(attackType, (resistances.get(attackType) || 0) + 1);
    }
  }
  const offensive = Object.keys(chart).map(defenseType => ({
    type: defenseType,
    factor: Math.max(1, ...[...attackTypes].map(attackType => chart[attackType]?.[defenseType] ?? 1))
  }));
  return {
    attackTypes: [...attackTypes],
    coveredTypes: offensive.filter(item => item.factor > 1).map(item => item.type),
    uncoveredTypes: offensive.filter(item => item.factor <= 1).map(item => item.type),
    risks: Object.keys(chart).map(type => ({ type, weak: weaknesses.get(type) || 0, resist: resistances.get(type) || 0 }))
      .filter(item => item.weak || item.resist)
      .sort((a, b) => (b.weak - b.resist) - (a.weak - a.resist))
  };
}

export function sanitizeTeam(raw, creatures, moves, skillPool) {
  const creatureMap = new Map(creatures.map(creature => [creature.key, creature]));
  return (Array.isArray(raw) ? raw : []).slice(0, 6).flatMap(member => {
    const creature = creatureMap.get(member?.creatureKey);
    if (!creature) return [];
    const allowed = new Set(skillPool(creature, moves).map(item => item.move?.name || item.name));
    return [{ creatureKey: creature.key, skills: [...new Set(member.skills || [])].filter(name => allowed.has(name)).slice(0, 4) }];
  });
}

export function recommendTeammates(members, creatures, moves, chart, effectiveness, skillPool, limit = 8) {
  if (!members.length || members.length >= 6) return [];
  const report = analyzeTeam(members, creatures, moves, chart, effectiveness);
  const selected = new Set(members.map(member => member.creatureKey));
  const priorityRisks = report.risks.filter(item => item.weak > item.resist);
  return creatures.filter(creature => !selected.has(creature.key)).map(creature => {
    const resisted = priorityRisks.filter(risk => effectiveness(risk.type, creature.types, chart) < 1);
    const weakTo = priorityRisks.filter(risk => effectiveness(risk.type, creature.types, chart) > 1);
    const damageTypes = new Set(skillPool(creature, moves).map(item => item.move)
      .filter(move => move && move.power > 0).map(move => move.type));
    const newCoverage = report.uncoveredTypes.filter(defenseType =>
      [...damageTypes].some(attackType => (chart[attackType]?.[defenseType] ?? 1) > 1));
    const score = resisted.reduce((sum, risk) => sum + 4 + risk.weak, 0)
      + newCoverage.length * 1.5 - weakTo.length * 2 + Math.min(2, damageTypes.size * .2);
    return {
      creatureKey: creature.key,
      score,
      resisted: resisted.map(item => item.type),
      newCoverage,
      reasons: [
        resisted.length ? `抵抗 ${resisted.map(item => item.type).join('、')}系` : '',
        newCoverage.length ? `补充 ${newCoverage.slice(0, 5).join('、')}系打击面` : ''
      ].filter(Boolean)
    };
  }).filter(item => item.score > 0 && item.reasons.length)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}
