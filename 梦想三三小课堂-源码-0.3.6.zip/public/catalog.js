import { STATS, TYPES } from './rules.js';
import { emptyBuild } from './data.js';

export function normalizeCreature(raw){
  const base={hp:Number(raw.stats.hp),atk:Number(raw.stats.attack),def:Number(raw.stats.defense),matk:Number(raw.stats.special_attack),mdef:Number(raw.stats.special_defense),speed:Number(raw.stats.speed)};
  if(!raw.pokemon_key || !raw.display_name || !Array.isArray(raw.attributes_list) || raw.attributes_list.some(t=>!TYPES.includes(t)) || STATS.some(k=>!Number.isInteger(base[k])))throw Error(`精灵数据无效：${raw.display_name||raw.pokemon_key}`);
  return {key:raw.pokemon_key,name:raw.display_name,baseName:raw.base_name,formName:raw.form_name,types:raw.attributes_list,base,ability:raw.ability||'',skillPools:raw.skills||{},evolution:raw.evolution||{},defenseProfile:raw.defense_profile||{}};
}
export function normalizeMove(raw){
  if(!raw.id || !raw.name || !TYPES.includes(raw.attribute))throw Error(`技能数据无效：${raw.name||raw.id}`);
  const category=raw.category==='物攻'?'physical':raw.category==='魔攻'?'magic':null;
  const power=raw.power===null||raw.power===undefined||raw.power===''?null:Number(raw.power);
  return {id:raw.id,name:raw.name,type:raw.attribute,category,categoryLabel:raw.category,power:Number.isFinite(power)?power:null,energy:raw.energy_consumption,description:raw.description||'',learners:raw.learners||[]};
}
export function buildFromCreature(creature){return {...emptyBuild(creature.name),key:creature.key,name:creature.name,types:[...creature.types],base:{...creature.base}}}
export function isDamageMove(move){return !!move.category && Number.isFinite(move.power)}
export function skillPool(creature,moves){
  if(!creature)return moves.map((move,index)=>({move,index,pool:'全部技能'}));
  const pools=[['普通技能',creature.skillPools?.moves],['技能石',creature.skillPools?.jinengshi],['血脉技能',creature.skillPools?.xuemai]];
  return pools.flatMap(([pool,names])=>{
    const list=Array.isArray(names)?names:names&&typeof names==='object'?Object.values(names):[];
    return list.map(name=>({move:moves.find(m=>m.name===name),index:moves.findIndex(m=>m.name===name),name,pool}));
  });
}
