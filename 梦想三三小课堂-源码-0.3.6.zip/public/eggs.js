export function matchEggs(eggs, height, weight) {
  const h = height === '' ? null : Number(height);
  const w = weight === '' ? null : Number(weight);
  if ((h === null && w === null) || (h !== null && (!Number.isFinite(h) || h <= 0)) || (w !== null && (!Number.isFinite(w) || w <= 0))) return [];
  return eggs.filter(egg =>
    (h === null || (Number.isFinite(egg.heightMin) && h >= egg.heightMin - 0.005 && h <= egg.heightMax + 0.005)) &&
    (w === null || (w >= egg.weightMin - 0.0005 && w <= egg.weightMax + 0.0005))
  ).map(egg => ({ ...egg, sizeVerdict: w === null ? '' : w <= egg.tinyMax + 0.0005 ? '小不点候选' : w >= egg.hugeMin - 0.0005 ? '大块头候选' : '普通范围' }));
}
