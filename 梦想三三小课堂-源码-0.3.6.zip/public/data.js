// 属性数据整理自 roco-claude/data/raw/type_chart.json (MIT)。未列出的关系均为 1 倍。
const strong = {
  草:'水 光 地',火:'草 冰 虫 机械',水:'火 地 机械',光:'幽 恶',地:'火 冰 电 毒',冰:'草 地 龙 翼',龙:'龙',电:'水 翼',毒:'草 萌',虫:'草 恶 幻',武:'普通 地 冰 恶 机械',翼:'草 虫 武',萌:'龙 武 恶',幽:'光 幽 幻',恶:'毒 萌 幽',机械:'地 冰 萌',幻:'毒 武'
};
const resist = {
  普通:'地 幽 机械',草:'火 龙 毒 虫 翼 机械',火:'水 地 龙',水:'草 冰 龙',光:'草 冰',地:'草 武',冰:'火 冰 机械',龙:'机械',电:'草 地 龙 电',毒:'地 毒 幽 机械',虫:'火 毒 武 翼 萌 幽 机械',武:'毒 虫 翼 萌 幽 幻',翼:'地 龙 电 机械',萌:'火 毒 机械',幽:'普通 恶',恶:'光 武 恶',机械:'火 水 电 机械',幻:'光 机械 幻'
};
export const defaultChart = Object.fromEntries(Object.keys({...strong,...resist}).map(type => {
  const row={};
  for(const target of (strong[type]||'').split(' ').filter(Boolean))row[target]=2;
  for(const target of (resist[type]||'').split(' ').filter(Boolean))row[target]=0.5;
  return [type,row];
}));
export const emptyBuild = (name='自定义精灵') => ({name,types:['普通'],base:{hp:100,atk:100,def:100,matk:100,mdef:100,speed:100},iv:{hp:0,atk:0,def:0,matk:0,mdef:0,speed:0},nature:{up:'',down:''}});
