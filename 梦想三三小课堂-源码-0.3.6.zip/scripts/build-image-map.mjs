import { readFileSync, writeFileSync } from 'node:fs';

const skills = readFileSync('wiki-skills.lua', 'utf8').split(/,skill_\d+=\{/);
const pets = readFileSync('wiki-catalog.lua', 'utf8').split(/,pet_\d+=\{/);
const catalog = JSON.parse(readFileSync('public/data/pokemon.json', 'utf8'));
const atlas = JSON.parse(readFileSync('public/data/atlas-path.json', 'utf8')).pets;
const field = (row, key) => row.match(new RegExp(`(?:^|,)${key}="([^"]+)"`))?.[1];
const normalize = value => String(value || '').replace(/[()（）·\s]/g, '');
const titleAliases = value => [
  value,
  value.replace('冬天的样子', ''),
  value.replace('储水期的样子', '储水时的样子'),
].map(normalize).filter((item, index, all) => item && all.indexOf(item) === index);

const skillIcons = {};
for (const row of skills) {
  const name = field(row, 'name'), icon = field(row, 'icon');
  if (name && icon && !skillIcons[name]) skillIcons[name] = icon;
}

const wikiPets = pets.map(row => ({
  name: field(row, 'name'), title: field(row, 'title'), number: field(row, 'number'),
  icon: field(row, 'head'), gameId: Number(row.match(/(?:^|,)game_id=(\d+)/)?.[1] || 0),
})).filter(pet => pet.name && pet.icon);
const atlasByTitle = new Map(Object.entries(atlas).map(([title,path]) => [normalize(title), `https://cdn.jsdelivr.net/gh/Entropy-Increase-Team/Rocom-Atlas@main${path}`]));
const petIcons = {};
const missing = [];
for (const creature of catalog) {
  const number = creature.pokemon_key.split(':')[0];
  const target = normalize(creature.display_name);
  const aliases = titleAliases(creature.display_name);
  const candidates = wikiPets.filter(pet => pet.number === number);
  const exact = wikiPets.find(pet => aliases.includes(normalize(pet.title)));
  const unqualified = candidates.find(pet => normalize(pet.title) === normalize(creature.base_name));
  const base = !creature.form_name && candidates.find(pet => normalize(pet.title).startsWith(target));
  const match = exact || (!creature.form_name && (unqualified || base)) ||
    (creature.form_name === '首领形态' && candidates.find(pet => normalize(pet.title).startsWith(target))) ||
    (candidates.length === 1 && candidates[0].name === creature.base_name ? candidates[0] : null);
  if (match) petIcons[creature.pokemon_key] = match.icon;
  else if (aliases.some(alias => atlasByTitle.has(alias))) {
    const alias = aliases.find(value => atlasByTitle.has(value));
    petIcons[creature.pokemon_key] = atlasByTitle.get(alias);
  }
  else missing.push(creature.display_name);
}

writeFileSync('public/data/wiki-icons.json', JSON.stringify({ pets: petIcons, skills: skillIcons }));
console.log(`精灵精确配图 ${Object.keys(petIcons).length}/${catalog.length}，技能名称配图 ${Object.keys(skillIcons).length}`);
console.log(`待补精灵图：${missing.join('、')}`);
