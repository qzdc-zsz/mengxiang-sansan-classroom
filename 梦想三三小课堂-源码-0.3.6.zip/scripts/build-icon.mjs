import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import sharp from 'sharp';
import pngToIco from 'png-to-ico';

const source = fileURLToPath(new URL('../梦想三三.jpg', import.meta.url));
const outputDir = new URL('../build/', import.meta.url);
const sizes = [16, 32, 48, 64, 128, 256];

await mkdir(outputDir, { recursive: true });

const pngs = await Promise.all(sizes.map(size =>
  sharp(source).resize(size, size, { fit: 'cover' }).png().toBuffer()
));

await writeFile(new URL('icon.ico', outputDir), await pngToIco(pngs));
await sharp(source)
  .resize(512, 512, { fit: 'cover' })
  .png()
  .toFile(fileURLToPath(new URL('icon.png', outputDir)));

console.log('Generated build/icon.ico and build/icon.png');
