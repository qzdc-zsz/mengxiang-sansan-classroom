import { readFile, writeFile, rename, copyFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';

const sources = [
  ['pokemon.json', 'public/data/pokemon.json', 'https://raw.githubusercontent.com/zyx20180209/roco-claude/main/data/raw/pokemon.json', 'json'],
  ['skills.json', 'public/data/skills.json', 'https://raw.githubusercontent.com/zyx20180209/roco-claude/main/data/raw/skills.json', 'json'],
  ['wiki-catalog.lua', 'wiki-catalog.lua', 'https://raw.githubusercontent.com/JayeGT002/rocom-wiki-data/main/wiki_modules/Pets/data/Catalog.lua', 'lua'],
  ['wiki-skills.lua', 'wiki-skills.lua', 'https://raw.githubusercontent.com/JayeGT002/rocom-wiki-data/main/wiki_modules/Pets/data/Skills.lua', 'lua'],
  ['egg-source.json', 'egg-source.json', 'https://raw.githubusercontent.com/PAIZ1999/roco_egg_master/main/src/pets_data.json', 'json'],
];

async function download([label, target, url, type]) {
  const response = await fetch(url, { headers: { 'user-agent': 'roco-world-helper' } });
  if (!response.ok) throw Error(`${label} 下载失败：HTTP ${response.status}`);
  const body = await response.text();
  if (type === 'json') JSON.parse(body);
  if (type === 'lua' && (!body.startsWith('return {') || body.length < 1000)) throw Error(`${label} 内容无效`);
  const temp = `${target}.new`;
  await writeFile(temp, body);
  return { label, target, temp, url, bytes: Buffer.byteLength(body) };
}

console.log('正在下载最新公开数据…');
const files = await Promise.all(sources.map(download));
for (const file of files) {
  try { await copyFile(file.target, `${file.target}.bak`); } catch {}
  await rename(file.temp, file.target);
  console.log(`已更新 ${file.label} (${file.bytes} bytes)`);
}
for (const script of ['scripts/build-skills-from-wiki.mjs', 'scripts/build-image-map.mjs', 'scripts/build-egg-data.mjs']) {
  const result = spawnSync(process.execPath, [script], { stdio: 'inherit' });
  if (result.status !== 0) throw Error(`${script} 生成失败`);
}
const counts = {
  creatures: JSON.parse(await readFile('public/data/pokemon.json', 'utf8')).length,
  skills: JSON.parse(await readFile('public/data/skills.json', 'utf8')).length,
};
const metadata = { syncedAt: new Date().toISOString(), counts, sources: files.map(({label,url,bytes})=>({label,url,bytes})) };
await writeFile('public/data/version.json', JSON.stringify(metadata, null, 2));
console.log(`同步完成：${metadata.syncedAt}`);
