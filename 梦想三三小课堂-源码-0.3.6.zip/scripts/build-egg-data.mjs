import { readFileSync, writeFileSync } from 'node:fs';

// The Wiki supplies egg weights; the community table supplies egg diameters.
const wiki = readFileSync('wiki-catalog.lua', 'utf8').split(/,pet_\d+=\{/);
const diameters = JSON.parse(readFileSync('egg-source.json', 'utf8'));
const groupNames = {1:'无法孵蛋',2:'巨灵组',3:'两栖组',4:'昆虫组',5:'天空组',6:'动物组',7:'妖精组',8:'植物组',9:'拟人组',10:'软体组',11:'大地组',12:'魔力组',13:'海洋组',14:'龙组',15:'机械组'};
const byName = new Map();
const groupsByName = {};
for (const row of wiki) {
  const name = row.match(/,name="([^"]+)",number=/)?.[1];
  const groupIds = row.match(/,egg_group=\{([^}]+)\}/)?.[1];
  if (name && groupIds) groupsByName[name] = groupIds.split(',').map(id => groupNames[id]).filter(Boolean);
  const size = row.match(/,egg_size=\{([^}]+)\}/)?.[1];
  if (!name || !size) continue;
  const get = key => Number(size.match(new RegExp(`(?:^|,)${key}=(\\d+)`))?.[1]);
  const min = get('min'), max = get('max');
  if (!min || !max) continue;
  byName.set(name, { name, weightMin: min / 1000, weightMax: max / 1000,
    tinyMax: get('mini_max') / 1000, hugeMin: get('huge_min') / 1000 });
}
for (const pet of diameters) {
  const egg = pet.egg_data;
  if (!egg || !Number.isFinite(egg.height_min) || !Number.isFinite(egg.height_max)) continue;
  const record = byName.get(pet.name) || { name: pet.name };
  record.heightMin = egg.height_min;
  record.heightMax = egg.height_max;
  record.groups = egg.egg_groups || [];
  if (!record.weightMin && Number.isFinite(egg.weight_min)) {
    record.weightMin = egg.weight_min;
    record.weightMax = egg.weight_max;
    record.tinyMax = egg.tiny_weight_line;
    record.hugeMin = egg.giant_weight_line;
  }
  byName.set(pet.name, record);
}
const result = [...byName.values()].filter(r => r.weightMin && r.weightMax).sort((a,b)=>a.name.localeCompare(b.name,'zh'));
writeFileSync('public/data/eggs.json', JSON.stringify(result));
writeFileSync('public/data/egg-groups.json', JSON.stringify(groupsByName));
console.log(`${result.length} egg weight ranges, ${result.filter(r=>r.heightMin).length} diameter ranges`);
