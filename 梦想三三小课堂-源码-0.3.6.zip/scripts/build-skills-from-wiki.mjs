import { readFileSync, writeFileSync } from 'node:fs';

const lua = readFileSync('wiki-skills.lua', 'utf8').split(/,skill_\d+=\{/);
const previous = JSON.parse(readFileSync('public/data/skills.json', 'utf8'));
const learnersByName = new Map(previous.map(skill => [skill.name, skill.learners || []]));
const field = (row, key) => row.match(new RegExp(`(?:^|,)${key}="([^"]*)"`))?.[1];
const numberField = (row, key) => row.match(new RegExp(`(?:^|,)${key}=(-?\\d+(?:\\.\\d+)?)`))?.[1];

const skills = [];
for (const row of lua) {
  const wikiCategory = field(row, 'category');
  if (!['攻击', '状态', '防御'].includes(wikiCategory)) continue;
  const name = field(row, 'name');
  const damageClass = field(row, 'damage_class');
  const element = field(row, 'element')?.replace(/系$/, '');
  if (!name || !element) continue;
  skills.push({
    id: String(numberField(row, 'game_id') || `wiki-${skills.length + 1}`),
    name,
    energy_consumption: numberField(row, 'energy') ?? '0',
    category: damageClass || wikiCategory,
    attribute: element,
    power: numberField(row, 'power') ?? null,
    description: field(row, 'desc') || '',
    learners: learnersByName.get(name) || [],
  });
}

if (skills.length < 500) throw Error(`Wiki 技能数量异常：${skills.length}`);
writeFileSync('public/data/skills.json', JSON.stringify(skills));
console.log(`已从 Wiki 构建 ${skills.length} 个战斗技能`);
