@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Install Node.js 20 or newer, then run this file again.
  pause
  exit /b 1
)
start "Roco World Helper" /min node "%~dp0server.js"
timeout /t 2 /nobreak >nul
start "" "http://localhost:5173/"
