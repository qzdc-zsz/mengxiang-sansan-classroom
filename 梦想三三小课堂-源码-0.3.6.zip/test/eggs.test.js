import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { matchEggs } from '../public/eggs.js';

const eggs = JSON.parse(readFileSync(new URL('../public/data/eggs.json', import.meta.url)));

test('蛋径和蛋重交叉筛选，并按估算区间提示体型', () => {
  const tiny = matchEggs(eggs, '0.23', '1.27').find(e => e.name === '喵喵');
  assert.equal(tiny?.sizeVerdict, '小不点候选');
  const giant = matchEggs(eggs, '0.23', '1.83').find(e => e.name === '喵喵');
  assert.equal(giant?.sizeVerdict, '大块头候选');
  assert.ok(matchEggs(eggs, '0.23', '99').length === 0);
});

test('仅蛋重时可查到没有蛋径资料的精灵', () => {
  const one = eggs.find(e => e.heightMin == null);
  assert.ok(one);
  assert.ok(matchEggs(eggs, '', String(one.weightMin)).some(e => e.name === one.name));
  assert.ok(!matchEggs(eggs, '0.23', String(one.weightMin)).some(e => e.name === one.name));
});
