import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const icons = JSON.parse(readFileSync(new URL('../public/data/wiki-icons.json', import.meta.url)));

test('鸭吉吉各形态使用各自的 Wiki 头像', () => {
  const expected = {
    '011:base':'PetAvatar_3012.png',
    '011:5':'PetAvatar_3036.png',
    '011:155':'PetAvatar_3452.png',
    '011:156':'PetAvatar_3453.png',
    '011:162':'PetAvatar_3742.png',
    '011:163':'PetAvatar_3495.png',
  };
  for (const [key,filename] of Object.entries(expected)) assert.equal(icons.pets[key],filename);
});

test('同名不同形态不能用基础名称覆盖', () => {
  assert.notEqual(icons.pets['011:base'],icons.pets['011:162']);
  assert.ok(icons.skills['绵里藏针']?.startsWith('Skill_'));
});
