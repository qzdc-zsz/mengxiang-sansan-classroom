import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateStats, calculateDamage, effectiveness, differenceMovePower, manaBurstPower, applyBattleModifiers, resolveMoveState } from '../public/rules.js';
import { emptyBuild } from '../public/data.js';

test('个体分配不能超过三项',()=>{
  const b=emptyBuild(); for(const k of ['hp','atk','def','matk'])b.iv[k]=1;
  assert.throws(()=>calculateStats(b),/最多只能给 3 项/);
});
test('魔能爆按剩余能量查表换算威力',()=>{
  assert.equal(manaBurstPower(0),45);
  assert.equal(manaBurstPower(4),135);
  assert.equal(manaBurstPower(10),210);
  assert.throws(()=>manaBurstPower(11),/0～10/);
});
test('能力值按社区公式计算',()=>{
  const b=emptyBuild();b.iv.atk=10;b.nature.up='atk';
  assert.equal(calculateStats(b).atk,233);
  assert.equal(calculateStats(b).hp,340);
});
test('性格可以提升或降低生命',()=>{
  const normal=emptyBuild(),boosted=emptyBuild(),reduced=emptyBuild();
  boosted.nature={up:'hp',down:'atk'};reduced.nature={up:'atk',down:'hp'};
  assert.ok(calculateStats(boosted).hp>calculateStats(normal).hp);
  assert.ok(calculateStats(reduced).hp<calculateStats(normal).hp);
});
test('双属性双弱为三倍，免疫为零',()=>{
  assert.equal(effectiveness('火',['草','冰'],{火:{草:2,冰:2}}),3);
  assert.equal(effectiveness('电',['水','地'],{电:{水:2,地:0}}),0);
});
test('伤害拆解、本系、雨天和连击',()=>{
  const a=emptyBuild(),d=emptyBuild();a.types=['水'];
  const r=calculateDamage(a,d,{type:'水',category:'physical',power:100},{水:{普通:2}},{rain:true,hits:2});
  assert.equal(r.factors.stab,1.25);
  assert.equal(r.factors.weather,1.5);
  assert.equal(r.factors.type,2);
  assert.equal(r.damage,r.perHit*2);
});
test('闪击和鸣沙陷阱按双方最终属性差动态计算威力',()=>{
  assert.equal(differenceMovePower('闪击',{speed:200},{speed:200}).power,60);
  assert.equal(differenceMovePower('闪击',{speed:201},{speed:200}).power,80);
  assert.equal(differenceMovePower('闪击',{speed:471},{speed:200}).power,200);
  assert.equal(differenceMovePower('鸣沙陷阱',{def:390},{def:200}).power,170);
  assert.equal(differenceMovePower('普通技能',{speed:999},{speed:1}),null);
});

test('战斗增益和减益先修正最终六维',()=>{
  const base={hp:400,atk:200,def:180,matk:160,mdef:150,speed:100};
  assert.deepEqual(applyBattleModifiers(base,{hp:-25,atk:50,def:-50,matk:0,mdef:20,speed:-10}),{hp:300,atk:300,def:90,matk:160,mdef:180,speed:90});
  const a=emptyBuild(),d=emptyBuild();
  const normal=calculateDamage(a,d,{name:'闪击',type:'普通',category:'physical',power:60},{},{});
  const boosted=calculateDamage(a,d,{name:'闪击',type:'普通',category:'physical',power:60},{},{attackerModifiers:{speed:100},defenderModifiers:{speed:-50}});
  assert.ok(boosted.factors.power>normal.factors.power);
});

test('物攻魔攻物防魔防和速度层数按各自每层幅度叠加',()=>{
  const base={hp:400,atk:200,def:200,matk:160,mdef:150,speed:100};
  const modified=applyBattleModifiers(base,{def:10},{atk:{layers:2,percent:25},matk:{layers:-1,percent:20},def:{layers:2,percent:20},mdef:{layers:-1,percent:30},speed:{layers:3,percent:5}});
  assert.equal(modified.atk,300);
  assert.equal(modified.matk,128);
  assert.equal(modified.def,300); // 手动 +10%，两层各 +20%
  assert.equal(modified.mdef,105);
  assert.equal(modified.speed,114);
  assert.throws(()=>applyBattleModifiers(base,{}, {speed:{layers:21,percent:10}}),/层数/);
});

test('叠层会修改技能威力与连击',()=>{
  assert.equal(resolveMoveState({name:'碎冰冰',power:40},{freezeLayers:3}).power,100);
  assert.equal(resolveMoveState({name:'鸩毒',power:75},{poisonLayers:2,counterStatus:true}).power,115);
  assert.equal(resolveMoveState({name:'多维击打',power:15},{hits:1,starLayers:4}).hits,5);
  assert.equal(resolveMoveState({name:'月光合奏',power:30},{hits:1,cuteLayers:5}).hits,6);
});

test('应对、永久威力和自身减益参与技能结算',()=>{
  assert.equal(resolveMoveState({name:'技巧打击',power:35},{counterStatus:true}).power,350);
  assert.equal(resolveMoveState({name:'连续爪击',power:30},{hits:3,counterStatus:true}).hits,6);
  assert.equal(resolveMoveState({name:'急中生智',power:60},{selfDebuffed:true,powerAdd:10,powerPercent:20}).power,132);
});

test('星陨印记按层数追加一次幻系伤害且不吃本系',()=>{
  const a=emptyBuild(),d=emptyBuild();a.types=['幻'];d.types=['普通'];
  const r=calculateDamage(a,d,{name:'普通攻击',type:'普通',category:'physical',power:50},{幻:{普通:2}},{starLayers:2});
  assert.equal(r.factors.starPower,28);
  assert.ok(r.starDamage>0);
  assert.equal(r.damage,r.skillDamage+r.starDamage);
});
