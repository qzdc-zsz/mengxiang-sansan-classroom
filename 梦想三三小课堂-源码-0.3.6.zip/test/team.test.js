import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeTeam, sanitizeTeam, recommendTeammates } from '../public/team.js';

const creatures=[
  {key:'a',name:'火灵',types:['火'],skillPools:{moves:['火球','错技']}},
  {key:'b',name:'水灵',types:['水'],skillPools:{moves:['水枪']}}
];
const moves=[{name:'火球',type:'火',power:50},{name:'水枪',type:'水',power:50}];
const chart={火:{火:.5,水:.5,草:2},水:{火:2,水:.5,草:.5},草:{火:.5,水:2,草:.5}};
const pool=(creature,all)=>creature.skillPools.moves.map(name=>({name,move:all.find(move=>move.name===name)}));
const effectiveness=(attack,types,table)=>types.reduce((factor,type)=>factor*(table[attack]?.[type]??1),1);

test('队伍导入会移除越池技能、重复技能和无效精灵',()=>{
  const result=sanitizeTeam([
    {creatureKey:'a',skills:['火球','水枪','火球']},
    {creatureKey:'missing',skills:['水枪']}
  ],creatures,moves,pool);
  assert.deepEqual(result,[{creatureKey:'a',skills:['火球']}]);
});

test('队伍分析统计进攻覆盖与防守弱点',()=>{
  const result=analyzeTeam([{creatureKey:'a',skills:['火球']},{creatureKey:'b',skills:['水枪']}],creatures,moves,chart,effectiveness);
  assert.deepEqual(result.attackTypes.sort(),['水','火']);
  assert.ok(result.coveredTypes.includes('火'));
  assert.ok(result.coveredTypes.includes('草'));
  assert.equal(result.risks.find(item=>item.type==='水').weak,1);
});

test('补位推荐优先选择能抵抗现有弱点的精灵',()=>{
  const result=recommendTeammates([{creatureKey:'a',skills:['火球']}],creatures,moves,chart,effectiveness,pool);
  assert.equal(result[0].creatureKey,'b');
  assert.ok(result[0].resisted.includes('水'));
  assert.ok(result[0].newCoverage.includes('火'));
});
