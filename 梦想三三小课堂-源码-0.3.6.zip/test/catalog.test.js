import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { normalizeCreature, normalizeMove, isDamageMove, skillPool } from '../public/catalog.js';

test('完整数据集可被图鉴适配器读取',()=>{
  const creatures=JSON.parse(readFileSync(new URL('../public/data/pokemon.json',import.meta.url))).map(normalizeCreature);
  const moves=JSON.parse(readFileSync(new URL('../public/data/skills.json',import.meta.url))).map(normalizeMove);
  assert.equal(creatures.length,499);
  assert.equal(moves.length,579);
  assert.equal(moves.filter(isDamageMove).length,358);
  assert.equal(moves.find(move=>move.name==='六自由度')?.power,30);
  assert.equal(moves.find(move=>move.name==='示弱')?.power,null);
  assert.equal(new Set(creatures.map(c=>c.key)).size,creatures.length);
  assert.equal(new Set(moves.map(m=>m.name)).size,moves.length);
});
test('首领形态的按属性血脉技能可以正常展开',()=>{
  const creatures=JSON.parse(readFileSync(new URL('../public/data/pokemon.json',import.meta.url))).map(normalizeCreature);
  const moves=JSON.parse(readFileSync(new URL('../public/data/skills.json',import.meta.url))).map(normalizeMove);
  const emperor=creatures.find(creature=>creature.name==='棋契陛下');
  const pool=skillPool(emperor,moves);
  assert.ok(pool.some(item=>item.pool==='血脉技能'&&item.name==='超维投射'));
  assert.ok(pool.some(item=>item.name==='鸣沙陷阱'));
});
